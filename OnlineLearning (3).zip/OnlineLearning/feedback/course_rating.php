$course_id = $_GET['course_id'];  // Assume course ID is passed in the URL
$student_id = $_SESSION['student_id'];  // Assume student ID is stored in session
$rating = $_POST['rating'];  // Rating submitted by the student
$feedback = $_POST['feedback'];  // Feedback submitted by the student
 
// Insert rating and feedback into the database
$sql = "INSERT INTO course_ratings (student_id, course_id, rating, feedback) VALUES (?, ?, ?, ?)";
$stmt = $db->prepare($sql);
$stmt->bind_param("iiis", $student_id, $course_id, $rating, $feedback);
$stmt->execute();
 
echo "Thank you for your feedback!";