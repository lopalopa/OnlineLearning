$course_id = $_GET['course_id'];  // Assume course ID is passed in the URL
$student_id = $_SESSION['student_id'];  // Assume student ID is stored in session
$post_content = $_POST['post_content'];  // Forum post submitted by the student
 
// Insert post into the database
$sql = "INSERT INTO discussion_forum (student_id, course_id, post_content) VALUES (?, ?, ?)";
$stmt = $db->prepare($sql);
$stmt->bind_param("iis", $student_id, $course_id, $post_content);
$stmt->execute();
 
echo "Your post has been submitted!";