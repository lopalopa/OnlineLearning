$post_id = $_GET['post_id'];  // Assume post ID is passed in the URL
$action = $_POST['action'];  // Action (approve or delete) submitted by the instructor
$moderator_id = $_SESSION['user_id'];  // Assume instructor's ID is stored in session
 
// Insert moderation action into the database
$sql = "INSERT INTO forum_moderation (moderator_id, post_id, action) VALUES (?, ?, ?)";
$stmt = $db->prepare($sql);
$stmt->bind_param("iis", $moderator_id, $post_id, $action);
$stmt->execute();
 
if ($action == 'Approved') {
    echo "The post has been approved.";
} else {
    echo "The post has been deleted.";
}