<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$user_role = $_SESSION['user_role'];
?>
<aside class="sidebar">
    <div class="sidebar-header">
        <h2>EduSphere</h2>
        <button class="toggle-btn" onclick="toggleSidebar()">☰</button>
    </div>

    <ul class="sidebar-menu">
        <?php if ($user_role === 'admin') { ?>
            <li><a href="../admin/admin_dashboard.php">🏠 Dashboard</a></li>
            <li><a href="#">👤 Manage Users</a>
                <ul class="submenu">
                    <li><a href="../admin/manage_users.php">📝 Manage Users</a></li>
                </ul>
            </li>


            <li><a href="#">📚 Manage Course</a>
                <ul class="submenu">
                    <li><a href="../courses/add_course.php">➕ Add New Course</a></li>
                    <li><a href="../courses/course_list_admin.php">📝 Manage Course</a></li>
                </ul>
            </li>

            <li><a href="#">🎓 Manage Lessons</a>
                <ul class="submenu">
                    <li><a href="../lessons/add_lesson.php">➕ Add Lesson</a></li>
                    <li><a href="../lessons/manage_lesson_list.php">📝 Manage Lessons</a></li>
                </ul>
            </li>
        <?php } else { ?>
            <li><a href="../user/user_dashboard.php">🏠 Dashboard</a></li>
            <li><a href="../user/profile.php">👤 My Profile</a></li>
            <li><a href="../courses/course_list_user.php">📚 View Courses</a></li>
        <?php } ?>
        <li><a href="../auth/logout.php" class="logout-btn">🚪 Logout</a></li>
    </ul>
</aside>

<script>
    function toggleSidebar() {
        document.querySelector(".sidebar").classList.toggle("collapsed");
    }
</script>

<style>
    .sidebar {
        position: fixed;
        left: 0;
        top: 0;
        width: 250px;
        height: 100%;
        background: linear-gradient(90deg, #6a11cb, #2575fc); /* vibrant gradient */
    color: white;
  transition: 0.3s ease;
        overflow-y: auto;
        z-index: 1000;
    }

    .sidebar-header {
        background: linear-gradient(90deg, #6a11cb, #2575fc); /* vibrant gradient */
        padding: 15px;
        position: relative;
        font-size: 22px;
        font-weight: bold;
        text-align: center;
    }

    .toggle-btn {
        position: absolute;
        right: 10px;
        top: 10px;
        background: #16A085;
        border: none;
        border-radius: 5px;
        color: white;
        font-size: 20px;
        padding: 4px 10px;
        cursor: pointer;
    }

    .sidebar-menu {
        list-style: none;
        margin: 0;
        padding: 0;
    }

    .sidebar-menu li {
        position: relative;
    }

    .sidebar-menu a {
        display: block;
        padding: 12px 20px;
        color: white;
        text-decoration: none;
        transition: background 0.3s, color 0.3s;
    }

    .sidebar-menu a:hover {
        background-color: #1ABC9C;
        color: #fff;
        border-left: 5px solid #F39C12;
    }

    .logout-btn {
        background-color: #E74C3C;
        text-align: center;
        margin: 20px;
        border-radius: 6px;
        transition: background-color 0.3s;
    }

    .logout-btn:hover {
        background-color: #C0392B;
    }

    /* Submenu */
    .submenu {
        background-color: #16A085; /* Slightly darker green for submenu contrast */
        padding-left: 15px;
        display: none;
        transition: 0.3s;
    }

    li:hover > .submenu {
        display: block;
    }

    /* Collapsed Mode */
    .collapsed {
        width: 60px;
    }

    .collapsed .sidebar-header h2,
    .collapsed .sidebar-menu a {
        display: none;
    }

    .collapsed .toggle-btn {
        right: 5px;
        top: 5px;
    }

    .collapsed .sidebar-menu li {
        text-align: center;
    }

    .collapsed .sidebar-menu a::before {
        content: attr(data-icon);
        font-size: 18px;
    }

    /* Scroll for longer menus */
    .sidebar::-webkit-scrollbar {
        width: 6px;
    }

    .sidebar::-webkit-scrollbar-thumb {
        background-color: #1abc9c;
        border-radius: 5px;
    }

    @media (max-width: 768px) {
        .sidebar {
            width: 60px;
        }

        .sidebar.collapsed {
            width: 250px;
        }

        .collapsed .sidebar-menu a {
            display: block;
        }
    }
</style>
