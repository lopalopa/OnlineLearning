<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get user info
$user_role = $_SESSION['user_role'];
$user_name = $_SESSION['user_name'];
?>

<header>
    <nav class="navbar">
        <div class="nav-logo">
            <a href="#" class="brand">EduSphere

</a>
        </div>
        <ul class="nav-links">
            <?php if ($user_role === 'admin') { ?>
                <li><a href="../admin/admin_dashboard.php">Home </a></li>
                <li><a href="../user/profile.php">My Profile</a></li>
            <?php } else { ?>
                <li><a href="../user/profile.php">My Profile</a></li>
            <?php } ?>
            <li class="user-info">Welcome, <strong><?php echo htmlspecialchars($user_name); ?></strong></li>
            <li><a href="../auth/logout.php" class="logout-btn">Logout</a></li>
        </ul>
        <button class="menu-toggle" onclick="toggleMenu()">☰</button>
    </nav>
</header>

<!-- JavaScript for Mobile Menu -->
<script>
    function toggleMenu() {
        document.querySelector(".nav-links").classList.toggle("active");
    }
</script>

<!-- Colorful Header Styles -->
<style>
    /* Base Styles */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    header {
        background: linear-gradient(90deg, #6a11cb, #2575fc); /* vibrant gradient */
        padding: 12px 0;
        width: 100%;
        position: fixed;
        top: 0;
        left: 0;
        z-index: 1000;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        max-width: 1200px;
        margin: auto;
        padding: 0 20px;
    }

    .nav-logo .brand {
        color: #fff;
        font-size: 24px;
        font-weight: bold;
        text-decoration: none;
        text-shadow: 1px 1px 2px #00000033;
    }

    .nav-links {
        list-style: none;
        display: flex;
        align-items: center;
        gap: 20px;
    }

    .nav-links li a {
        text-decoration: none;
        color: #ffffff;
        font-size: 16px;
        padding: 8px 15px;
        border-radius: 6px;
        transition: background-color 0.3s, color 0.3s;
    }

    .nav-links li a:hover {
        background-color: #ffffff;
        color: #2575fc;
    }

    .user-info {
        color: #f1f1f1;
        font-weight: bold;
    }

    .logout-btn {
        background-color: #ff6b6b;
        color: white;
        padding: 8px 14px;
        border-radius: 6px;
        text-decoration: none;
        transition: background-color 0.3s;
    }

    .logout-btn:hover {
        background-color: #e63946;
    }

    .menu-toggle {
        display: none;
        font-size: 26px;
        background: none;
        border: none;
        color: white;
        cursor: pointer;
    }

    @media (max-width: 768px) {
        .nav-links {
            display: none;
            flex-direction: column;
            background: linear-gradient(90deg, #6a11cb, #2575fc);
            width: 100%;
            position: absolute;
            top: 60px;
            left: 0;
            padding: 15px 0;
        }

        .nav-links.active {
            display: flex;
        }

        .nav-links li {
            text-align: center;
        }

        .menu-toggle {
            display: block;
        }
    }
</style>
