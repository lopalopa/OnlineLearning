<!-- Font Awesome CDN (include in <head> or before this footer) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<footer class="footer text-white pt-4" style="background: linear-gradient(90deg, #2c3e50, #3498db);">
    <div class="container text-center">
        <div class="mb-3">
            <a href="#" class="text-white me-4"><i class="fab fa-facebook fa-lg"></i></a>
            <a href="#" class="text-white me-4"><i class="fab fa-twitter fa-lg"></i></a>
            <a href="#" class="text-white me-4"><i class="fab fa-instagram fa-lg"></i></a>
            <a href="#" class="text-white me-4"><i class="fab fa-linkedin fa-lg"></i></a>
            <a href="#" class="text-white me-4"><i class="fab fa-youtube fa-lg"></i></a>
            <a href="#" class="text-white me-4"><i class="fab fa-github fa-lg"></i></a>
        </div>
        <p class="mb-0">&copy; <?php echo date("Y"); ?> <strong>EduSphere</strong>. All rights reserved.</p>
    </div>
</footer>
