$student_id = $_SESSION['student_id'];  // Student's ID from session
$sql = "SELECT * FROM student_achievements WHERE student_id = ?";
$stmt = $db->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
 
if ($result->num_rows > 0) {
    while ($achievement = $result->fetch_assoc()) {
        echo "Achievement Type: " . $achievement['achievement_type'] . " - Date: " . $achievement['achievement_date'] . "<br>";
    }
} else {
    echo "No achievements found.";
}