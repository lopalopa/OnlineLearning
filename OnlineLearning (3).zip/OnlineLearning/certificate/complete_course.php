$student_id = $_SESSION['student_id']; // Assume student ID is stored in session
$course_id = $_GET['course_id'];  // Assume course ID is passed in the URL
 
// Check if all lessons are completed
$sql = "SELECT COUNT(*) AS completed_lessons FROM lesson_progress WHERE student_id = ? AND course_id = ? AND status = 'Completed'";
$stmt = $db->prepare($sql);
$stmt->bind_param("ii", $student_id, $course_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
 
// If all lessons are completed
$total_lessons = getTotalLessonsForCourse($course_id);  // Custom function to fetch total lessons for the course
if ($row['completed_lessons'] == $total_lessons) {
    // Update course completion status
    $update_sql = "UPDATE course_completions SET completed_at = NOW() WHERE student_id = ? AND course_id = ?";
    $stmt = $db->prepare($update_sql);
    $stmt->bind_param("ii", $student_id, $course_id);
    $stmt->execute();
 
    echo "Course completed! You can now download your certificate.";
} else {
    echo "Please complete all lessons to finish the course.";
}