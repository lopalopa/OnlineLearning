$student_id = $_GET['student_id'];
$course_id = $_GET['course_id'];
 
// Check if the instructor has the permission to approve
if (isInstructor($user_id)) {  // Custom function to check instructor's role
    $sql = "UPDATE course_completions SET completed_at = NOW() WHERE student_id = ? AND course_id = ?";
    $stmt = $db->prepare($sql);
    $stmt->bind_param("ii", $student_id, $course_id);
    $stmt->execute();
 
    echo "Course marked as completed for the student!";
} else {
    echo "You do not have permission to approve completion for this student.";
}