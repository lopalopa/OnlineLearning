$student_id = $_SESSION['student_id'];
$course_id = $_GET['course_id'];
 
// Check if the student has completed the course
$sql = "SELECT * FROM course_completions WHERE student_id = ? AND course_id = ? AND completed_at IS NOT NULL";
$stmt = $db->prepare($sql);
$stmt->bind_param("ii", $student_id, $course_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    // Fetch student and course data
    $student_data = getStudentData($student_id);  // Custom function to get student details
    $course_data = getCourseData($course_id);  // Custom function to get course details
 
    // Generate certificate (you can use a PDF library for this)
    $certificate_data = "<h1>Certificate of Completion</h1>";
    $certificate_data .= "<p>This is to certify that <b>" . $student_data['name'] . "</b> has successfully completed the course <b>" . $course_data['title'] . "</b>.</p>";
    $certificate_data .= "<p>Completed on: " . date("F j, Y") . "</p>";
 
    // Save certificate details in the database
    $certificate_url = saveCertificate($student_id, $course_id, $certificate_data);  // Custom function to save certificate
    echo "<a href='" . $certificate_url . "'>Download your certificate</a>";
} else {
    echo "You must complete the course before downloading your certificate.";
}