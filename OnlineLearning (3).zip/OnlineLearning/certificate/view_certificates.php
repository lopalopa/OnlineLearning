$student_id = $_SESSION['student_id'];  // Student's ID from session
$sql = "SELECT * FROM certificates WHERE student_id = ?";
$stmt = $db->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();
 
if ($result->num_rows > 0) {
    while ($certificate = $result->fetch_assoc()) {
        echo "Certificate for Course ID: " . $certificate['course_id'] . " - <a href='" . $certificate['certificate_url'] . "'>View Certificate</a><br>";
    }
} else {
    echo "No certificates found.";
}