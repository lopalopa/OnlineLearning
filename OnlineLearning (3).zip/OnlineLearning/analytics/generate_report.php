$student_id = $_GET['student_id'];
$sql = "SELECT * FROM student_performance WHERE student_id = ?";
$result = $db->query($sql);
$student_performance = $result->fetch_assoc();
 
$report_data = "Student ID: " . $student_performance['student_id'] . "\n";
$report_data .= "Progress: " . $student_performance['progress_percentage'] . "%\n";

$report_data .= "Completed Lessons: " . $student_performance['completed_lessons'] . "\n";
$report_data .= "Quiz Score: " . $student_performance['quiz_score'] . "\n";
 
// Insert the report into the database
$sql_insert = "INSERT INTO performance_reports (student_id, report_data) VALUES (?, ?)";
$stmt = $db->prepare($sql_insert);
$stmt->bind_param("is", $student_id, $report_data);
$stmt->execute();