$sql = "SELECT student_id, progress_percentage, quiz_score FROM student_performance WHERE module_id = ?";
$result = $db->query($sql);
 
while ($row = $result->fetch_assoc()) {
    echo "Student ID: " . $row['student_id'] . " Progress: " . $row['progress_percentage'] . "% Quiz Score: " . $row['quiz_score'] . "<br>";
}