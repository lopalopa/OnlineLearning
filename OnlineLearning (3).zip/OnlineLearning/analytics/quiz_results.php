$quiz_id = $_GET['quiz_id'];  // Get quiz_id from URL or form submission
$sql = "SELECT * FROM quiz_scores WHERE student_id = ? AND quiz_id = ?";
$result = $db->query($sql);
$quiz_result = $result->fetch_assoc();
 
echo "Score: " . $quiz_result['score'] . "/100";