$student_id = $_SESSION['student_id'];  // Assume student_id is stored in session
$sql = "SELECT * FROM student_performance WHERE student_id = ?";
$result = $db->query($sql);
$performance = $result->fetch_assoc();
 
echo "Progress: " . $performance['progress_percentage'] . "%";
echo "Completed Lessons: " . $performance['completed_lessons'] . " / " . $performance['total_lessons'];

echo "Quiz Score: " . $performance['quiz_score'] . "/100";