<?php

include '../db/db.php';

 

if (isset($_GET['course_id'])) {

    $course_id = $_GET['course_id'];

 

    $sql = "SELECT * FROM lessons WHERE course_id='$course_id' ORDER BY lesson_order ASC";

    $result = mysqli_query($conn, $sql);

 

    echo "<h2>Lessons List</h2><ul>";

    while ($row = mysqli_fetch_assoc($result)) {

        echo "<li><strong>{$row['lesson_order']}. {$row['title']}</strong><br>";

        echo "Video: <a href='{$row['video_url']}' target='_blank'>Watch</a><br>";

        echo "File: <a href='{$row['file_url']}' download>Download</a><br>";

        echo "<a href='view_lesson.php?lesson_id={$row['id']}'>View Details</a></li><hr>";

    }

    echo "</ul>";

} else {

    echo "Course ID not specified.";

}

?>