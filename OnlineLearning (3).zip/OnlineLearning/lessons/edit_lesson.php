<?php
include '../db/db.php';

$lesson = null;
$alertMessage = "";
$alertClass = "";

// Check if lesson ID is passed
if (isset($_GET['id'])) {
    $lesson_id = intval($_GET['id']);
    $result = mysqli_query($conn, "SELECT * FROM lessons WHERE id = $lesson_id");

    if ($result && mysqli_num_rows($result) > 0) {
        $lesson = mysqli_fetch_assoc($result);
    } else {
        die("<div class='alert alert-danger m-4'>Lesson not found.</div>");
    }
} else {
    die("<div class='alert alert-danger m-4'>No lesson ID specified.</div>");
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lesson_id = $_POST['lesson_id'];
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $content = mysqli_real_escape_string($conn, $_POST['content']);
    $video_url = mysqli_real_escape_string($conn, $_POST['video_url']);
    $file_url = mysqli_real_escape_string($conn, $_POST['file_url']);
    $lesson_order = $_POST['lesson_order'];

    $sql = "UPDATE lessons
            SET title='$title', content='$content', video_url='$video_url', file_url='$file_url', lesson_order='$lesson_order'
            WHERE id='$lesson_id'";

    if (mysqli_query($conn, $sql)) {
        $alertMessage = "✅ Lesson updated successfully!";
        $alertClass = "alert-success";
        // Update lesson values so form reflects changes immediately
        $lesson = [
            'id' => $lesson_id,
            'title' => $title,
            'content' => $content,
            'video_url' => $video_url,
            'file_url' => $file_url,
            'lesson_order' => $lesson_order
        ];
    } else {
        $alertMessage = "❌ Error: " . mysqli_error($conn);
        $alertClass = "alert-danger";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Lesson</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            min-height: 100vh;

            background-image:
                linear-gradient(to right, rgba(0, 180, 216, 0.8), rgba(0, 119, 182, 0.8)),
                url('../assets/images/bg.jpg'); /* Update with actual path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
</style>
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-warning text-dark">
            <h4 class="text-center mb-0">✏️ Edit Lesson</h4>
        </div>
        <div class="card-body">

            <?php if (!empty($alertMessage)): ?>
                <div class="alert <?= $alertClass; ?>"><?= $alertMessage; ?></div>
            <?php endif; ?>

            <form method="POST" action="">
                <input type="hidden" name="lesson_id" value="<?php echo htmlspecialchars($lesson['id']); ?>">

                <div class="mb-3">
                    <label for="title" class="form-label">Lesson Title</label>
                    <input type="text" class="form-control" name="title" id="title"
                           value="<?php echo htmlspecialchars($lesson['title']); ?>" required>
                </div>

                <div class="mb-3">
                    <label for="content" class="form-label">Lesson Content</label>
                    <textarea class="form-control" name="content" id="content" rows="4"><?php echo htmlspecialchars($lesson['content']); ?></textarea>
                </div>

                <div class="mb-3">
                    <label for="video_url" class="form-label">Video URL</label>
                    <input type="url" class="form-control" name="video_url" id="video_url"
                           value="<?php echo htmlspecialchars($lesson['video_url']); ?>">
                </div>

                <div class="mb-3">
                    <label for="file_url" class="form-label">File URL</label>
                    <input type="url" class="form-control" name="file_url" id="file_url"
                           value="<?php echo htmlspecialchars($lesson['file_url']); ?>">
                </div>

                <div class="mb-3">
                    <label for="lesson_order" class="form-label">Lesson Order</label>
                    <input type="number" class="form-control" name="lesson_order" id="lesson_order"
                           value="<?php echo htmlspecialchars($lesson['lesson_order']); ?>">
                </div>

                <div class="text-center">
                    <button type="submit" class="btn btn-success px-4">
                        <i class="bi bi-save"></i> Update Lesson
                    </button>
                    <a href="manage_lesson_list.php" class="btn btn-secondary ms-2">Back</a>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
