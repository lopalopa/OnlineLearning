<?php
include '../db/db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Lessons</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            min-height: 100vh;

            background-image:
                linear-gradient(to right, rgba(0, 180, 216, 0.8), rgba(0, 119, 182, 0.8)),
                url('../assets/images/bg.jpg'); /* Update with actual path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
</style>
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-warning text-dark">
            <h4 class="text-center">🛠️ Manage Lessons</h4>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-bordered table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Course</th>
                        <th>Title</th>
                        <th>Order</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT lessons.*, courses.title AS course_title 
                              FROM lessons 
                              JOIN courses ON lessons.course_id = courses.id 
                              ORDER BY lessons.course_id";
                    $result = mysqli_query($conn, $query);
                    if ($result && mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>
                                <td>{$row['id']}</td>
                                <td>{$row['course_title']}</td>
                                <td>{$row['title']}</td>
                                <td>{$row['lesson_order']}</td>
                                <td>
                                    <a href='view_lesson.php?id={$row['id']}' class='btn btn-sm btn-info'>View</a>
                                    <a href='edit_lesson.php?id={$row['id']}' class='btn btn-sm btn-primary'>Edit</a>
                                    <a href='delete_lesson.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                                </td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5' class='text-center'>No lessons available</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
