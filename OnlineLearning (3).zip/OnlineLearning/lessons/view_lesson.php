<?php
include '../db/db.php';

// Check if the 'id' is set in the URL
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $lesson_id = $_GET['id'];

    // Query to fetch lesson details by ID
    $query = "SELECT lessons.*, courses.title AS course_title 
              FROM lessons 
              JOIN courses ON lessons.course_id = courses.id 
              WHERE lessons.id = $lesson_id";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $lesson = mysqli_fetch_assoc($result);
    } else {
        echo "<script>alert('Lesson not found.'); window.location.href='manage_lessons.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('Invalid lesson ID.'); window.location.href='manage_lessons.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Lesson</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            min-height: 100vh;
            background-image:
                linear-gradient(to right, rgba(0, 180, 216, 0.8), rgba(0, 119, 182, 0.8)),
                url('../assets/images/bg.jpg'); /* Update with actual path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
    </style>
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-warning text-dark">
            <h4 class="text-center">🛠️ View Lesson</h4>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-6">
                    <strong>Course:</strong> <?= htmlspecialchars($lesson['course_title']) ?>
                </div>
                <div class="col-md-6">
                    <strong>Lesson Title:</strong> <?= htmlspecialchars($lesson['title']) ?>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-6">
                    <strong>Lesson Order:</strong> <?= htmlspecialchars($lesson['lesson_order']) ?>
                </div>
                <div class="col-md-6">
                    <strong>Created At:</strong> <?= date("Y-m-d H:i:s", strtotime($lesson['created_at'])) ?>
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-md-12">
                    <strong>Lesson Content:</strong>
                    <div><?= nl2br(htmlspecialchars($lesson['content'])) ?></div>
                </div>
            </div>

            <a href="manage_lesson_list.php" class="btn btn-warning">Back to Lessons List</a>
        </div>
    </div>
</div>
</body>
</html>
