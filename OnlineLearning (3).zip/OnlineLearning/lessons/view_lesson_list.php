<?php
include '../db/db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Lesson List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-info text-white">
            <h4 class="text-center">📚 Lesson List</h4>
        </div>
        <div class="card-body table-responsive">
            <table class="table table-bordered table-striped">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Course</th>
                        <th>Title</th>
                        <th>Order</th>
                        <th>Video</th>
                        <th>File</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = "SELECT lessons.*, courses.title AS course_title 
                              FROM lessons 
                              JOIN courses ON lessons.course_id = courses.id 
                              ORDER BY lessons.course_id, lessons.lesson_order";
                    $result = mysqli_query($conn, $query);
                    if ($result && mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>
                                <td>{$row['id']}</td>
                                <td>{$row['course_title']}</td>
                                <td>{$row['title']}</td>
                                <td>{$row['lesson_order']}</td>
                                <td><a href='{$row['video_url']}' target='_blank'>Video</a></td>
                                <td><a href='{$row['file_url']}' target='_blank'>File</a></td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6' class='text-center'>No lessons found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
