<?php
include '../db/db.php';

if (isset($_GET['id'])) {
    $lesson_id = intval($_GET['id']); // Sanitizing

    $sql = "DELETE FROM lessons WHERE id = $lesson_id";

    if (mysqli_query($conn, $sql)) {
        header("Location: manage_lesson_list.php?status=deleted");
        exit;
    } else {
        echo "<div class='alert alert-danger'>❌ Error: " . mysqli_error($conn) . "</div>";
    }
} else {
    echo "<div class='alert alert-warning'>⚠️ No lesson ID provided.</div>";
}
?>
