<?php
include '../db/db.php';

if (isset($_GET['course_id'])) {
    $course_id = intval($_GET['course_id']);
    $query = "SELECT title FROM courses WHERE id = $course_id LIMIT 1";
    $result = mysqli_query($conn, $query);
    
    if ($result && $row = mysqli_fetch_assoc($result)) {
        echo htmlspecialchars($row['title']);
    } else {
        echo '';
    }
}
?>
