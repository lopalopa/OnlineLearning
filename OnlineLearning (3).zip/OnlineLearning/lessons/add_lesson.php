<?php
include '../db/db.php';

$alertMessage = "";
$alertClass = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course_id = $_POST['course_id'];
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $content = mysqli_real_escape_string($conn, $_POST['content']);
    $video_url = mysqli_real_escape_string($conn, $_POST['video_url']);
    $file_url = mysqli_real_escape_string($conn, $_POST['file_url']);
    $lesson_order = $_POST['lesson_order'];

    $sql = "INSERT INTO lessons (course_id, title, content, video_url, file_url, lesson_order)
            VALUES ('$course_id', '$title', '$content', '$video_url', '$file_url', '$lesson_order')";

    if (mysqli_query($conn, $sql)) {
        $alertMessage = "✅ Lesson added successfully!";
        $alertClass = "alert-success";
    } else {
        $alertMessage = "❌ Error: " . mysqli_error($conn);
        $alertClass = "alert-danger";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Lesson</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
                body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            min-height: 100vh;

            background-image:
                linear-gradient(to right, rgba(0, 180, 216, 0.8), rgba(0, 119, 182, 0.8)),
                url('../assets/images/bg.jpg'); /* Update with actual path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

    </style>
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white text-center">
            <h4><i class="bi bi-plus-circle"></i> Add New Lesson</h4>
        </div>
        <div class="card-body">
            <?php if (!empty($alertMessage)): ?>
                <div class="alert <?= $alertClass; ?>" role="alert">
                    <?= $alertMessage; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="add_lesson.php">
            <div class="mb-3">
    <label for="course_id" class="form-label">Select Course</label>
    <select class="form-select" name="course_id" id="course_id" required>
        <option value="">-- Select a course --</option>
        <?php
        // Fetch course ID and title from the database
        $courseQuery = "SELECT id, title FROM courses ORDER BY title ASC";
        $courseResult = mysqli_query($conn, $courseQuery);

        if ($courseResult && mysqli_num_rows($courseResult) > 0) {
            while ($course = mysqli_fetch_assoc($courseResult)) {
                echo '<option value="' . $course['id'] . '">' . $course['id'] . ' - ' . htmlspecialchars($course['title']) . '</option>';
            }
        } else {
            echo '<option disabled>No courses found</option>';
        }
        ?>
    </select>
</div>
<div class="mb-3">
    <label for="title" class="form-label">Lesson Title (auto-filled from course)</label>
    <input type="text" class="form-control" name="title" id="title" required>
</div>
                <div class="mb-3">
                    <label for="content" class="form-label">Lesson Description</label>
                    <textarea class="form-control" name="content" rows="4"></textarea>
                </div>
                <div class="mb-3">
                    <label for="video_url" class="form-label">Video URL</label>
                    <input type="url" class="form-control" name="video_url" placeholder="https://...">
                </div>
                <div class="mb-3">
                    <label for="file_url" class="form-label">File URL (PDF)</label>
                    <input type="url" class="form-control" name="file_url" placeholder="https://...">
                </div>
                <div class="mb-3">
                    <label for="lesson_order" class="form-label">Lesson Order</label>
                    <input type="number" class="form-control" name="lesson_order" value="1">
                </div>
                <div class="text-center">
                    <button type="submit" class="btn btn-success"><i class="bi bi-save"></i> Add Lesson</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap Icons CDN (Optional but nice) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $('#course_id').on('change', function () {
        var courseId = $(this).val();
        if (courseId) {
            $.ajax({
                url: 'get_course_title.php',
                type: 'GET',
                data: { course_id: courseId },
                success: function (data) {
                    $('#title').val(data);
                }
            });
        } else {
            $('#title').val('');
        }
    });
</script>
