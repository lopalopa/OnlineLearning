<?php
// contact.php - Contact Page for Online Learning Platform
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Contact Us | Online Learning Platform</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;600&display=swap" rel="stylesheet" />
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f9f9f9;
      color: #333;
    }

    a {
      text-decoration: none;
      color: #00b4d8;
    }

    header {
      background-color: #1a1a2e;
      color: #fff;
      padding: 20px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    header h2 {
      font-size: 24px;
    }

    nav ul {
      display: flex;
      list-style: none;
    }

    nav ul li {
      margin-left: 20px;
    }

    nav ul li a {
      color: #fff;
      font-weight: 500;
    }

    .container {
      max-width: 1000px;
      margin: auto;
      padding: 60px 20px;
    }

    .contact-heading {
      text-align: center;
      margin-bottom: 40px;
    }

    .contact-heading h1 {
      font-size: 2.5rem;
      margin-bottom: 10px;
    }

    .contact-form {
      background: #fff;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
    }

    .contact-form form {
      display: flex;
      flex-direction: column;
    }

    .contact-form input,
    .contact-form textarea {
      margin-bottom: 20px;
      padding: 15px;
      border-radius: 5px;
      border: 1px solid #ddd;
      font-size: 1rem;
    }

    .contact-form textarea {
      resize: vertical;
      min-height: 150px;
    }

    .contact-form button {
      background-color: #00b4d8;
      color: white;
      padding: 15px;
      border: none;
      border-radius: 5px;
      font-weight: bold;
      font-size: 1rem;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .contact-form button:hover {
      background-color: #007ea7;
    }

    .contact-info {
      margin-top: 60px;
      text-align: center;
      color: #555;
    }

    .contact-info p {
      margin-bottom: 10px;
    }

    footer {
      background-color: #1a1a2e;
      color: #fff;
      text-align: center;
      padding: 20px 0;
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        text-align: center;
      }

      nav ul {
        flex-direction: column;
        margin-top: 10px;
      }

      nav ul li {
        margin: 10px 0;
      }
    }
  </style>
</head>

<body>
  <!-- Navbar -->
  <header>
    <h2>Online Learning</h2>
    <nav>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="courses/display_list.php">Courses</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="auth/new_login.php">Login</a></li>
        <li><a href="auth/new_register.php">Sign Up</a></li>
      </ul>
    </nav>
  </header>

  <!-- Contact Section -->
  <section class="container">
    <div class="contact-heading">
      <h1>Contact Us</h1>
      <p>We'd love to hear from you! Please fill out the form below and we’ll get back to you shortly.</p>
    </div>

    <div class="contact-form">
      <form action="submit_contact.php" method="POST">
        <input type="text" name="name" placeholder="Your Name" required />
        <input type="email" name="email" placeholder="Your Email" required />
        <input type="text" name="subject" placeholder="Subject" required />
        <textarea name="message" placeholder="Your Message" required></textarea>
        <button type="submit">Send Message</button>
      </form>
    </div>

    <div class="contact-info">
      <h3>Other Ways to Reach Us</h3>
      <p>Email: <a href="mailto:support@onlinelearning.com">support@onlinelearning.com</a></p>
      <p>Phone: +1 (555) 123-4567</p>
      <p>Location: 123 Education Lane, Learnville, ED 45678</p>
    </div>
  </section>

  <!-- Footer -->
  <footer>
    <p>&copy; 2025 Online Learning Platform. All rights reserved.</p>
  </footer>
</body>

</html>
