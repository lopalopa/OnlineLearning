<?php
session_start();
include '../db/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "
    SELECT c.*, uc.* 
    FROM courses c 
    JOIN user_courses uc ON c.id = uc.course_id 
    WHERE uc.user_id = $user_id
";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Courses</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            min-height: 100vh;

            background-image:
                linear-gradient(to right, rgba(0, 180, 216, 0.8), rgba(0, 119, 182, 0.8)),
                url('../assets/images/bg.jpg'); /* Update with actual path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .course-card {
            border: 1px solid #dee2e6;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.05);
            transition: transform 0.2s ease;
        }
        .course-card:hover {
            transform: translateY(-5px);
        }
        .course-title {
            font-size: 1.5rem;
            color: #0d6efd;
            font-weight: 600;
        }
        .enroll-date {
            color: #6c757d;
        }
    </style>
</head>
<body>

<div class="container py-5">
    <h2 class="text-center text-primary mb-4">📚 My Enrolled Courses</h2>

    <?php if (mysqli_num_rows($result) > 0): ?>
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <?php while ($course = mysqli_fetch_assoc($result)) { ?>
                <div class="col">
                    <div class="card course-card h-100">
                        <div class="card-body">
                            <h5 class="course-title"><?= htmlspecialchars($course['title']) ?></h5>
                            <p class="enroll-date mb-3">Enrolled on: <?= date("F d, Y", strtotime($course['enrolled_at'])) ?></p>
                            <a href="course_in_detail.php?id=<?= $course['id'] ?>" class="btn btn-primary">Start Learning</a>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    <?php else: ?>
        <div class="alert alert-warning text-center">
            You haven't enrolled in any courses yet.
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
