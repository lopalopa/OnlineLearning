<?php 
// Include database connection
include('../db/db.php');

// Fetch all courses
$query = "SELECT * FROM courses ORDER BY create_at DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course List</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Updated background color with a smooth light blue gradient */
        body {
            background: linear-gradient(135deg, #4facfe, #00f2fe); /* Light blue gradient */
            font-family: 'Arial', sans-serif;
            color: #333; /* Darker text color for better contrast */
            padding-top: 50px;
        }

        .container {
            max-width: 1200px;
            background-color: rgba(255, 255, 255, 0.9); /* Semi-transparent white background */
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Soft shadow for a card-like effect */
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.5rem;
            font-weight: bold;
            color: #2c3e50; /* Dark text for heading */
        }

        .table th,
        .table td {
            vertical-align: middle;
        }

        .thead-dark {
            background-color: #34495e; /* Dark gray for header */
            color: #fff;
        }

        .btn-custom {
            background-color: #28a745;
            color: white;
            border-radius: 50px;
            font-weight: bold;
            padding: 10px 20px;
        }

        .btn-custom:hover {
            background-color: #218838;
        }

        .btn-danger-custom {
            background-color: #dc3545;
            color: white;
            border-radius: 50px;
            font-weight: bold;
            padding: 10px 20px;
        }

        .btn-danger-custom:hover {
            background-color: #c82333;
        }

        .alert-info {
            background-color: #17a2b8;
            color: white;
            font-size: 1.2rem;
        }

        .table-responsive {
            margin-top: 40px;
        }

        .table-bordered th,
        .table-bordered td {
            border: 1px solid #ddd;
        }

        .table-striped tbody tr:nth-child(odd) {
            background-color: rgba(0, 0, 0, 0.05); /* Slight darkening for alternate rows */
        }

        .btn-success {
            background-color: #007bff;
            color: white;
            border-radius: 50px;
            padding: 12px 24px;
            font-weight: bold;
        }

        .btn-success:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>

    <div class="container">

        <h2>Course List</h2>

        <!-- Display courses in a table -->
        <?php if ($result->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Price</th>
                            <th>Created At</th>
                            <th>Actions</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($course = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $course['id']; ?></td>
                                <td><?php echo $course['title']; ?></td>
                                <td>$<?php echo number_format($course['price'], 2); ?></td>
                                <td><?php echo $course['create_at']; ?></td>
                                <td class="action-btns">
                                    <a href="course_detail.php?id=<?php echo $course['id']; ?>" class="btn btn-custom">View</a>
                                  </td>
                           
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info" role="alert">
                No courses available.
            </div>
        <?php endif; ?>

        <!-- Add New Course Button -->
     
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.min.js"></script>

</body>

</html>

<?php
// Close connection
$conn->close();
?>
