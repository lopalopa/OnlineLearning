<?php
session_start();
include '../db/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$course_id = $_GET['id'] ?? null;

if (!$course_id) {
    echo "Invalid course.";
    exit();
}

$check_enrollment = mysqli_query($conn, "SELECT * FROM user_courses WHERE user_id = $user_id AND id = $course_id");
if (mysqli_num_rows($check_enrollment) == 0) {
    echo "You are not enrolled in this course. <a href='course_detail.php?id=$course_id'>Go back</a>";
    exit();
}

$row = mysqli_fetch_assoc($check_enrollment);
$course_id = $row['course_id'];
$enrolled_at = $row['enrolled_at'];

$course = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM courses WHERE id = $course_id"));
$duration_months = (int) $course['duration'];

$admission_date = new DateTime($enrolled_at);
$admission_date->modify("+$duration_months months");
$completion_date = $admission_date->format('Y-m-d');

$today = date('Y-m-d');
$can_generate_certificate = ($today >= $completion_date);

$lessons = mysqli_query($conn, "SELECT * FROM lessons WHERE course_id = $course_id ORDER BY id ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $course['title'] ?> - Course Detail</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
            body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            min-height: 100vh;

            background-image:
                linear-gradient(to right, rgba(0, 180, 216, 0.8), rgba(0, 119, 182, 0.8)),
                url('../assets/images/bg.jpg'); /* Update with actual path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }.course-header {
        background: linear-gradient(to right, #0d6efd, #6610f2);
        color: white;
        border-radius: 10px;
        padding: 25px;
        margin-bottom: 30px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }
    .lesson-card {
    width: 100%; /* Full width by default */
margin: 0 auto; /* Center the card */
    border-radius: 12px;
    transition: all 0.3s ease;
}
.lesson-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 15px rgba(0,0,0,0.1);
}
    .btn-generate {
        font-size: 1.1rem;
    }
    </style>
</head>
<body>

<div class="container mt-4">

    <!-- Back Button -->
    <div class="mb-3">
        <a href="my_courses.php" class="btn btn-outline-primary">&larr; Back to Course Page</a>
    </div>

    <!-- Course Header -->
    <div class="course-header">
        <h1 class="mb-2"><?= htmlspecialchars($course['title']) ?></h1>
        <p class="mb-1"><strong>Instructor:</strong> <?= htmlspecialchars($course['instructor']) ?></p>
        <p class="mb-1"><strong>Duration:</strong> <?= $course['duration'] ?> months</p>
        <p class="mb-1"><strong>Admission Date:</strong> <?= $enrolled_at ?></p>
        <p class="mb-0"><strong>Description:</strong> <?= nl2br(htmlspecialchars($course['description'])) ?></p>
    </div>

    <!-- Lessons Section -->
    <h3 class="text-dark mb-3">📘 Course Lessons</h3>

    <?php if (mysqli_num_rows($lessons) == 0): ?>
        <div class="alert alert-danger">No lessons available yet for this course.</div>
    <?php else: ?>
        <div class="row row-cols-1 row-cols-md-2 g-4">
            <?php while ($lesson = mysqli_fetch_assoc($lessons)) { ?>
                <div class="col">
                    <div class="card lesson-card h-100">
                        <div class="card-body">
                            <h5 class="card-title text-primary"><?= htmlspecialchars($lesson['title']) ?></h5>
                            <div class="card-text text-secondary">
                                <?= $lesson['content'] ? nl2br(htmlspecialchars($lesson['content'])) : '<em>No content available.</em>' ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    <?php endif; ?>

    <!-- Certificate Section -->
    <div class="mt-5">
        <?php if ($can_generate_certificate): ?>
            <form method="post" action="generate_certificate.php">
                <input type="hidden" name="course_id" value="<?= $course_id ?>">
                <input type="hidden" name="user_id" value="<?= $user_id ?>">
                <button type="submit" class="btn btn-success btn-generate">
                    🎓 Generate Certificate
                </button>
            </form>
        <?php else: ?>
            <div class="alert alert-warning">
                📅 Certificate will be available after <strong><?= $completion_date ?></strong>.
            </div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
