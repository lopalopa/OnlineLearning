 <?php
// session_start();
// include('../db/db.php');

// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//     $course_id = $_POST['course_id'];
//     $user_id = $_POST['user_id'];
//     $payment_method = $_POST['payment_method'];
//     $enrolled_at = date("Y-m-d H:i:s");

//     // Optional payment details
//     $card_number = $_POST['card_number'] ?? '';
//     $upi_id = $_POST['upi_id'] ?? '';
//     $payment_details = '';

//     if ($payment_method === 'Credit Card') {
//         $payment_details = "Card Number: " . mysqli_real_escape_string($conn, $card_number);
//     } elseif ($payment_method === 'UPI') {
//         $payment_details = "UPI ID: " . mysqli_real_escape_string($conn, $upi_id);
//     }

//     // Insert enrollment with payment details
//     $query = "INSERT INTO user_courses (user_id, course_id, payment_method, payment_details, enrolled_at) 
//               VALUES ('$user_id', '$course_id', '$payment_method', '$payment_details', '$enrolled_at')";

//     if (mysqli_query($conn, $query)) {
//         echo "<script>alert('Enrollment successful!'); window.location.href='course_detail_user_new.php';</script>";
//     } else {
//         echo "Error: " . mysqli_error($conn);
//     }
// } else {
//     echo "Invalid request.";
// }
?> 
<?php
session_start();
include('../db/db.php');
require('../vendor/razorpay/razorpay/Razorpay.php'); // Include Razorpay PHP SDK

use Razorpay\Api\Api;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Fetch the form data
    $course_id = $_POST['course_id'];
    $user_id = $_POST['user_id'];
    $payment_method = $_POST['payment_method'];
    $enrolled_at = date("Y-m-d H:i:s");

    // Optional payment details for different methods
    $card_number = $_POST['card_number'] ?? '';
    $upi_id = $_POST['upi_id'] ?? '';
    $expiry_date = $_POST['expiry_date'] ?? '';
    $cvv = $_POST['cvv'] ?? '';
    $payment_details = '';

    // Payment details based on the chosen payment method
    if ($payment_method === 'Credit Card') {
        // Example: Store card number details (you could further add validation if needed)
        $payment_details = "Card Number: " . mysqli_real_escape_string($conn, $card_number) . ", Expiry Date: " . mysqli_real_escape_string($conn, $expiry_date);
    } elseif ($payment_method === 'UPI') {
        // Store UPI ID if the user chooses UPI
        $payment_details = "UPI ID: " . mysqli_real_escape_string($conn, $upi_id);
    }

    // Initialize Razorpay API (only for Credit Card)
    if ($payment_method === 'Credit Card') {
        $key_id = 'your_razorpay_key_id';
        $key_secret = 'your_razorpay_key_secret';
        $api = new Api($key_id, $key_secret);

        // Create Razorpay order data
        $orderData = [
            'receipt' => rand(1000, 9999), // Random receipt ID
            'amount' => 1000 * 100, // Amount in paise (1000 INR = 100000 paise)
            'currency' => 'INR',
            'payment_capture' => 1 // Auto-capture payment
        ];

        try {
            // Create the order with Razorpay
            $razorpayOrder = $api->order->create($orderData);
            $razorpayOrderId = $razorpayOrder->id;
            $_SESSION['razorpay_order_id'] = $razorpayOrderId;

            // Store the enrollment record in the database
            $query = "INSERT INTO user_courses (user_id, course_id, payment_method, payment_details, enrolled_at, razorpay_order_id) 
                      VALUES ('$user_id', '$course_id', '$payment_method', '$payment_details', '$enrolled_at', '$razorpayOrderId')";

            if (mysqli_query($conn, $query)) {
                // Redirect user to Razorpay checkout page
                echo "<script src='https://checkout.razorpay.com/v1/checkout.js'></script>";
                echo "<script>
                    var options = {
                        'key': '$key_id', // Your Razorpay Key ID
                        'order_id': '$razorpayOrderId', // Razorpay Order ID
                        'handler': function (response) {
                            // Handle successful payment
                            window.location.href = 'payment_success.php?payment_id=' + response.razorpay_payment_id;
                        },
                        'prefill': {
                            'name': 'John Doe',
                            'email': 'john@example.com',
                            'contact': '1234567890'
                        },
                        'theme': {
                            'color': '#F37254'
                        }
                    };
                    var rzp1 = new Razorpay(options);
                    rzp1.open();
                </script>";
            } else {
                echo "Error: " . mysqli_error($conn);
            }
        } catch (Exception $e) {
            echo "Error: " . $e->getMessage();
        }
    } elseif ($payment_method === 'UPI') {
        // Handle UPI payment details (for now, just store them)
        // Store the enrollment record with UPI details
        $query = "INSERT INTO user_courses (user_id, course_id, payment_method, payment_details, enrolled_at) 
                  VALUES ('$user_id', '$course_id', '$payment_method', '$payment_details', '$enrolled_at')";

        if (mysqli_query($conn, $query)) {
            echo "<script>alert('Enrollment successful! Please complete your UPI payment.'); window.location.href='course_detail_user_new.php';</script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Invalid payment method selected.";
    }
} else {
    echo "Invalid request.";
}
?>
