<?php
// Include database connection
include('../db/db.php');

// Check if course ID is provided
if (isset($_GET['id'])) {
    $course_id = $_GET['id'];

    // Fetch course details
    $query = "SELECT * FROM courses WHERE id = '$course_id'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $course = $result->fetch_assoc();
    } else {
        die("Course not found!");
    }
} else {
    die("Invalid request. Course ID is required.");
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Details</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f7f6;
            padding-top: 50px;
        }

        .course-card {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        .course-thumbnail {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }

        .btn-custom {
            background-color: #007bff;
            color: white;
            font-size: 16px;
        }

        .btn-custom:hover {
            background-color: #0056b3;
        }

        .back-btn {
            margin-top: 20px;
            font-size: 16px;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            min-height: 100vh;

            background-image:
                linear-gradient(to right, rgba(0, 180, 216, 0.8), rgba(0, 119, 182, 0.8)),
                url('../assets/images/bg.jpg'); /* Update with actual path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

    </style>
</head>

<body>

<div class="container mt-5">
    <!-- Course Details Card -->
    <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10 col-sm-12">
            <div class="card shadow-lg rounded">
                <div class="card-body">
                    <h2 class="text-center text-primary"><?php echo isset($course['title']) ? $course['title'] : ''; ?></h2>
                    <hr>

                    <!-- Course Description -->
                    <h5 class="mt-4 text-success">Description:</h5>
                    <p><?php echo isset($course['description']) ? $course['description'] : 'No description available.'; ?></p>

                    <!-- Course Price -->
                    <h5 class="mt-3 text-warning">Price:</h5>
                    <p class="font-weight-bold">$<?php echo isset($course['price']) ? number_format($course['price'], 2) : '0.00'; ?></p>

                    <!-- Course Created At -->
                    <h5 class="mt-3 text-muted">Created At:</h5>
                    <p><?php echo isset($course['create_at']) ? $course['create_at'] : ''; ?></p>

                    <!-- Course Thumbnail -->
                    <?php if (!empty($course['thumbnail'])): ?>
                        <h5 class="mt-3 text-info">Course Thumbnail:</h5>
                        <p><?php echo isset($course['thumbnail']) ? $course['thumbnail'] : ''; ?></p>
                    <?php endif; ?>

                    <!-- Enroll Now Button -->
                    <!-- <a href="enroll.php?course_id=<?= $course['id'] ?>" class="btn btn-success btn-lg w-100 mt-4">Enroll Now</a> -->

<!-- Enroll Now Button (Triggers Modal) -->
<button class="btn btn-success btn-lg w-100 mt-4" data-toggle="modal" data-target="#paymentModal">Enroll Now</button>
                    <!-- Back Button -->
                    <a href="course_list_user.php" class="btn btn-outline-primary btn-lg w-100 mt-3">Back to Courses</a>
                <!-- Payment Modal -->
<div class="modal fade" id="paymentModal" tabindex="-1" role="dialog" aria-labelledby="paymentModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <form method="POST" action="process_enrollment.php">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="paymentModalLabel">Choose Payment Method</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
  <!-- Payment Options -->
  <div class="form-group">
    <label for="payment_method">Select a payment option:</label>
    <select class="form-control" name="payment_method" id="payment_method" onchange="togglePaymentDetails()" required>
      <option value="">--Select--</option>
      <option value="Credit Card">Credit Card</option>
      <option value="Debit Card">Debit Card</option>
      <option value="UPI">UPI</option>
      <option value="Net Banking">Net Banking</option>
      <option value="Cash">Cash</option>
    </select>
  </div>

  <!-- Credit Card Details -->
  <div id="credit_card_fields" style="display: none;">
    <div class="form-group">
      <label for="card_number">Card Number:</label>
      <input type="text" class="form-control" name="card_number" placeholder="Enter card number">
    </div>
    <div class="form-group">
      <label for="expiry">Expiry Date:</label>
      <input type="text" class="form-control" name="expiry" placeholder="MM/YY">
    </div>
    <div class="form-group">
      <label for="cvv">CVV:</label>
      <input type="password" class="form-control" name="cvv" placeholder="CVV">
    </div>
  </div>

  <!-- UPI ID -->
  <div id="upi_fields" style="display: none;">
    <div class="form-group">
      <label for="upi_id">UPI ID:</label>
      <input type="text" class="form-control" name="upi_id" placeholder="example@upi">
    </div>
  </div>

  <!-- Hidden Fields -->
  <input type="hidden" name="course_id" value="<?= $course['id'] ?>">
  <input type="hidden" name="user_id" value="<?= $_SESSION['user_id'] ?? 1 ?>">
</div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Confirm Enrollment</button>
        </div>
      </div>
    </form>
  </div>
</div>
</div>
            </div>
        </div>
    </div>
</div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.min.js"></script>
    <script>
        function togglePaymentDetails() {
    const paymentMethod = document.getElementById('payment_method').value;
    
    // Hide all fields initially
    document.getElementById('creditCardFields').style.display = 'none';
    
    if (paymentMethod === 'Credit Card') {
        document.getElementById('creditCardFields').style.display = 'block';
    }
}

  document.getElementById('payment_method').addEventListener('change', function () {
    const method = this.value;
    document.getElementById('credit_card_fields').style.display = (method === 'Credit Card') ? 'block' : 'none';
    document.getElementById('upi_fields').style.display = (method === 'UPI') ? 'block' : 'none';
  });
</script>

</body>

</html>
