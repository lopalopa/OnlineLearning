<?php

// Include database connection

include('../db/db.php');

// Check if course ID is provided

if (isset($_GET['id'])) {

    $course_id = $_GET['id'];

 

    // Delete query

    $query = "DELETE FROM courses WHERE id = '$course_id'";

 

    if ($conn->query($query) === TRUE) {

        echo "Course deleted successfully.";

    } else {

        echo "Error: " . $query . "<br>" . $conn->error;

    }

} else {

    echo "Invalid request. Course ID is required.";

}

 

// Close connection

$conn->close();

?>