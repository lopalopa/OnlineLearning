<?php 

// Include database connection
include('../db/db.php');

// Get course details if 'id' is provided
if (isset($_GET['id'])) {
    $course_id = $_GET['id'];

    $query = "SELECT * FROM courses WHERE id = '$course_id'";

    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $course = $result->fetch_assoc();
    } else {
        die("Course not found!");
    }
}

// Handling form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course_id = $_POST['course_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $thumbnail = $_POST['thumbnail'];

    // Input validation
    if (empty($title) || empty($price)) {
        echo "<div class='alert alert-danger'>Title and price are required!</div>";
    } else {
        // Update query
        $query = "UPDATE courses SET
                  title = '$title',
                  description = '$description',
                  price = '$price',
                  thumbnail = '$thumbnail'
                  WHERE id = '$course_id'";

        if ($conn->query($query) === TRUE) {
            echo "<div class='alert alert-success'>Course updated successfully.</div>";
        } else {
            echo "<div class='alert alert-danger'>Error: " . $query . "<br>" . $conn->error . "</div>";
        }
    }
}

// Close connection
$conn->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Course</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f9fa;
            padding-top: 50px;
        }

        .container {
            max-width: 800px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        .form-control {
            margin-bottom: 10px;
        }

        .btn-custom {
            background-color: #007bff;
            color: white;
        }

        .btn-custom:hover {
            background-color: #0056b3;
        }

        .alert {
            margin-top: 20px;
        }
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            min-height: 100vh;

            background-image:
                linear-gradient(to right, rgba(0, 180, 216, 0.8), rgba(0, 119, 182, 0.8)),
                url('../assets/images/bg.jpg'); /* Update with actual path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
    </style>
</head>
<?php include '../include/header.php';?>


<body>


    <div class="container mt-5">
        

        <h2>Edit Course</h2>

        <form action="edit_course.php" method="POST">

            <input type="hidden" name="course_id" value="<?php echo isset($course['id']) ? $course['id'] : ''; ?>">

            <!-- Course Title -->
            <div class="form-group">
                <label for="title">Course Title:</label>
                <input type="text" class="form-control" name="title" value="<?php echo isset($course['title']) ? $course['title'] : ''; ?>" required>
            </div>

            <!-- Course Description -->
            <div class="form-group">
                <label for="description">Description:</label>
                <textarea class="form-control" name="description" rows="5"><?php echo isset($course['description']) ? $course['description'] : ''; ?></textarea>
            </div>

            <!-- Course Price -->
            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" class="form-control" name="price" step="0.01" value="<?php echo isset($course['price']) ? $course['price'] : ''; ?>" required>
            </div>

            <!-- Course Thumbnail -->
            <div class="form-group">
                <label for="thumbnail">Thumbnail URL:</label>
                <input type="text" class="form-control" name="thumbnail" value="<?php echo isset($course['thumbnail']) ? $course['thumbnail'] : ''; ?>">
            </div>

            <button type="submit" class="btn btn-custom btn-block">Update Course</button>
        </form>

        <br>

        <a href="courses.php" class="btn btn-secondary btn-block">Back to Course List</a>
        </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.min.js"></script>
</body>

</html>
<?php include '../include/footer.php';?>