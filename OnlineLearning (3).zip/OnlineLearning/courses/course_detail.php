<?php
// Include database connection
include('../db/db.php');

// Check if course ID is provided
if (isset($_GET['id'])) {
    $course_id = $_GET['id'];

    // Fetch course details
    $query = "SELECT * FROM courses WHERE id = '$course_id'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $course = $result->fetch_assoc();
    } else {
        die("Course not found!");
    }
} else {
    die("Invalid request. Course ID is required.");
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Details</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f4f7f6;
            padding-top: 50px;
        }

        .course-card {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        .course-thumbnail {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }

        .btn-custom {
            background-color: #007bff;
            color: white;
            font-size: 16px;
        }

        .btn-custom:hover {
            background-color: #0056b3;
        }

        .back-btn {
            margin-top: 20px;
            font-size: 16px;
        }
    </style>
</head>

<body>

    <div class="container">
        <!-- Course Details Card -->
        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-10 col-sm-12">
                <div class="course-card">
                    <h2 class="text-center"><?php echo isset($course['title']) ? $course['title'] : ''; ?></h2>
                    <hr>

                    <!-- Course Description -->
                    <h5>Description:</h5>
                    <p><?php echo isset($course['description']) ? $course['description'] : 'No description available.'; ?></p>

                    <!-- Course Price -->
                    <h5>Price:</h5>
                    <p>$<?php echo isset($course['price']) ? number_format($course['price'], 2) : '0.00'; ?></p>

                    <!-- Course Created At -->
                    <h5>Create At:</h5>
                    <p><?php echo isset($course['create_at']) ? $course['create_at'] : ''; ?></p>

                    <!-- Course Thumbnail -->
                    <?php if (!empty($course['thumbnail'])): ?>
                        <h5>Course Thumbnail:</h5>
                        <p><?php echo isset($course['thumbnail']) ? $course['thumbnail'] : ''; ?></p>
                        <?php endif; ?>
                        <a href="enroll.php?course_id=<?= $course['id'] ?>">Enroll Now</a>


                    <!-- Back Button -->
                    <a href="display_list.php" class="btn btn-custom btn-block back-btn">Back to Courses</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.min.js"></script>

</body>

</html>
