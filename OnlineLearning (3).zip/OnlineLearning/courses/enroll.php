
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Enrollment</title>
     <style>
        body {
            background-image:
                linear-gradient(to right, rgba(0, 180, 216, 0.8), rgba(0, 119, 182, 0.8)),
                url('../assets/images/bg.jpg'); /* Update with actual path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
       height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }
        

        .card-container {
            background-color: #ffffff;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            padding: 30px;
            border-radius: 15px;
            max-width: 600px;
            width: 100%;
        }

        .card {
            border-radius: 15px;
        }

        .alert {
            font-size: 1.2rem;
            padding: 20px;
            font-weight: bold;
        }

        .btn-back {
            background-color: #0d6efd;
            color: white;
            font-weight: bold;
            padding: 12px 25px;
            border-radius: 5px;
            text-transform: uppercase;
            margin-top: 15px;
        }

        .btn-back:hover {
            background-color: #6610f2;
        }

        .btn-back:focus {
            outline: none;
            box-shadow: none;
        }

        h2 {
            color: #0d6efd;
            font-size: 2rem;
        }

    </style>
</head>
<?php
session_start();
include '../db/db.php'; // your database connection file

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get user ID and course ID
$user_id = $_SESSION['user_id'];
$course_id = $_GET['course_id'] ?? null;

if (!$course_id) {
    echo "<div class='alert alert-danger mt-4'>Invalid course ID.</div>";
    exit();
}

// Check if already enrolled
$check = mysqli_query($conn, "SELECT * FROM user_courses WHERE user_id = $user_id AND course_id = $course_id");
if (mysqli_num_rows($check) > 0) {
    echo '<div class="card-container">
            <div class="card text-center">
                <div class="card-body">';
    
    // Corrected link
    echo '<a href="course_detail_user.php?id=' . $course_id . '">Back</a>';

    echo "<div class='alert alert-warning mt-4'>You are already enrolled in this course. <a href='my_courses.php' class='alert-link'>Go to My Courses</a></div>";
    
    exit();
    echo '</div></div></div>';
}

// Enroll the user
$insert = mysqli_query($conn, "INSERT INTO user_courses (user_id, course_id) VALUES ($user_id, $course_id)");

?>
<body>

<div class="card-container">
    <div class="card text-center">
        <div class="card-body">
            <?php if ($insert): ?>
                <h2>Enrollment Success!</h2>
                <div class="alert alert-success">

                    You have been successfully enrolled in the course! 
                    <a href="my_courses.php" class="alert-link">Go to My Courses</a>
                    <a href="course_detail_user.php" class="alert-link">Back to Previus</a>

                </div>
            <?php else: ?>
                <h2>Oops!</h2>
                <div class="alert alert-danger">
                    Enrollment failed. Please try again later.
                </div>
            <?php endif; ?>

            <a href="my_courses.php" class="btn btn-back">Back to My Courses</a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
