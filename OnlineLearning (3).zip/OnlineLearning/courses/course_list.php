<?php
// Include database connection
include('../db/db.php');

// Fetch all courses
$query = "SELECT * FROM courses ORDER BY create_at DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course List</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            font-family: 'Arial', sans-serif;
            color: #fff;
            padding-top: 50px;
        }

        .container {
            max-width: 1200px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-size: 2.5rem;
        }

        .table th,
        .table td {
            vertical-align: middle;
        }

        .action-btns a {
            margin: 0 10px;
            font-size: 16px;
        }

        .btn-custom {
            background-color: #28a745;
            color: white;
            border-radius: 50px;
            padding: 10px 20px;
            font-weight: bold;
        }

        .btn-custom:hover {
            background-color: #218838;
        }

        .btn-danger-custom {
            background-color: #dc3545;
            color: white;
            border-radius: 50px;
            padding: 10px 20px;
            font-weight: bold;
        }

        .btn-danger-custom:hover {
            background-color: #c82333;
        }

        .table-responsive {
            margin-top: 40px;
        }

        .thead-dark {
            background-color: #333;
            color: #fff;
        }

        .table-striped tbody tr:nth-child(odd) {
            background-color: rgba(255, 255, 255, 0.1);
        }

        .table-bordered th, .table-bordered td {
            border: 1px solid #ddd;
        }

        .alert-info {
            color: #fff;
            background-color: #17a2b8;
            border-color: #17a2b8;
            font-size: 1.2rem;
        }

        .btn-success {
            background-color: #007bff;
            color: white;
            border-radius: 50px;
            padding: 12px 24px;
            font-weight: bold;
        }

        .btn-success:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<?php include '../include/header.php';?>
<body>

    <div class="container">

        <div class="row">

        <div class="col-md-3">
            <?php include '../include/sidebar.php';?>
        </div>
        
        <div class="col-md-9 mt-5">
            <div style="text-align: right;" class="mt-5">
            <a href="add_course.php" style="text-align: right;" class="btn btn-success btn-lg">Add New Course</a>
        </div>

        <h2>Course List</h2>

        <!-- Display courses in a table -->
        <?php if ($result->num_rows > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Price</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($course = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $course['id']; ?></td>
                                <td><?php echo $course['title']; ?></td>
                                <td>$<?php echo number_format($course['price'], 2); ?></td>
                                <td><?php echo $course['create_at']; ?></td>
                                <td class="action-btns">
                                    <a href="course_detail.php?id=<?php echo $course['id']; ?>" class="btn btn-custom">View</a>
                                    <a href="edit_course.php?id=<?php echo $course['id']; ?>" class="btn btn-warning">Edit</a>
                                    <a href="delete_course.php?id=<?php echo $course['id']; ?>" class="btn btn-danger-custom" onclick="return confirm('Are you sure?');">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info" role="alert">
                No courses available.

            </div>
        <?php endif; ?>

        <!-- Add New Course Button -->
        </div>


<!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.min.js"></script>

</body>

</html>
<?php include '../include/footer.php';?>
<?php
// Close connection
$conn->close();
?>