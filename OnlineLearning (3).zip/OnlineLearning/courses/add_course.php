<?php
session_start();
include('../db/db.php');

$success = $error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $teacher_id = $_SESSION['user_id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $instructor = $_POST['instructor'];
    $duration = $_POST['duration'];

    // Handle thumbnail upload
    $thumbnail = '';
    if (isset($_FILES['thumbnail']) && $_FILES['thumbnail']['error'] == 0) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $filename = time() . "_" . basename($_FILES["thumbnail"]["name"]);
        $target_file = $target_dir . $filename;

        if (move_uploaded_file($_FILES["thumbnail"]["tmp_name"], $target_file)) {
            $thumbnail = $target_file;
        } else {
            $error = "Thumbnail upload failed.";
        }
    }

    if (empty($title) || empty($price) || empty($instructor) || empty($duration)) {
        $error = "All fields are required!";
    } elseif (empty($thumbnail)) {
        $error = "Please upload a course thumbnail.";
    } else {
        $query = "INSERT INTO courses (teacher_id, title, description, price, thumbnail, instructor, duration)
                  VALUES ('$teacher_id', '$title', '$description', '$price', '$thumbnail', '$instructor', '$duration')";

        if ($conn->query($query) === TRUE) {
            $success = "New course added successfully.";
        } else {
            $error = "Error: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Course</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
                body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            min-height: 100vh;

            background-image:
                linear-gradient(to right, rgba(0, 180, 216, 0.8), rgba(0, 119, 182, 0.8)),
                url('../assets/images/bg.jpg'); /* Update with actual path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

        .btn-custom {
            background-color: #007bff;
            color: white;
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
        .form-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <div class="col-md-8 offset-md-2">
        <div class="form-container">
            <h2 class="text-center">Add a New Course</h2>

            <?php if (!empty($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <form action="add_course.php" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label>Course Title</label>
                    <input type="text" name="title" class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Course Description</label>
                    <textarea name="description" class="form-control" rows="4"></textarea>
                </div>

                <div class="form-group">
                    <label>Price ($)</label>
                    <input type="number" name="price" class="form-control" step="0.01" required>
                </div>

                <div class="form-group">
                    <label>Course Thumbnail (Image)</label>
                    <input type="file" name="thumbnail" class="form-control-file" accept="image/*" required>
                </div>

                <div class="form-group">
                    <label>Instructor Name</label>
                    <input type="text" name="instructor" class="form-control" required>
                </div>

                <div class="form-group">
                    <label>Duration (e.g., 6 weeks, 10 hours)</label>
                    <input type="text" name="duration" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-custom btn-block">Add Course</button>
            </form>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.min.js"></script>
</body>
</html>
