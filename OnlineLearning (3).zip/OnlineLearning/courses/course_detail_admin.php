<?php
include('../db/db.php');

if (isset($_GET['id'])) {
    $course_id = $_GET['id'];
    $query = "SELECT * FROM courses WHERE id = '$course_id'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $course = $result->fetch_assoc();
    } else {
        die("Course not found!");
    }
} else {
    die("Invalid request. Course ID is required.");
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f9f9f9, #e0eafc);
            padding-top: 60px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .course-card {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .course-card:hover {
            transform: translateY(-5px);
        }

        h2 {
            font-weight: bold;
            margin-bottom: 30px;
            color: #333;
        }

        h5 {
            color: #555;
            margin-top: 20px;
        }

        p {
            color: #666;
            font-size: 16px;
        }

        .thumbnail-img {
            margin-top: 15px;
            max-width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .btn-custom {
            background-color: #28a745;
            color: white;
            font-size: 16px;
            padding: 12px 20px;
            border-radius: 30px;
            margin-top: 30px;
        }

        .btn-custom:hover {
            background-color: #218838;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-10">
                <div class="course-card">
                    <h2 class="text-center"><?php echo $course['title']; ?></h2>
                    <hr>

                    <h5>Description:</h5>
                    <p><?php echo !empty($course['description']) ? $course['description'] : 'No description available.'; ?></p>

                    <h5>Price:</h5>
                    <p><strong>$<?php echo number_format($course['price'], 2); ?></strong></p>

                    <h5>Created At:</h5>
                    <p><?php echo $course['create_at']; ?></p>

                    <?php if (!empty($course['thumbnail'])): ?>
                        <h5>Course Thumbnail:</h5>
                        <img src="<?php echo $course['thumbnail']; ?>" alt="Course Thumbnail" class="thumbnail-img">
                    <?php endif; ?>

                    <a href="course_list_admin.php" class="btn btn-custom btn-block">← Back to Courses</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
