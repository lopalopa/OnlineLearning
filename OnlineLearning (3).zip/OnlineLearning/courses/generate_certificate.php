<?php
include '../db/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_id = $_POST['course_id'];
    $user_id = $_POST['user_id'];

    // Fetch user details
    $user_result = mysqli_query($conn, "SELECT name FROM users WHERE id = $user_id");
    $user = mysqli_fetch_assoc($user_result);

    // Fetch course details
    $course_result = mysqli_query($conn, "SELECT title, instructor, duration FROM courses WHERE id = $course_id");
    $course = mysqli_fetch_assoc($course_result);

    // Fetch enrollment date
    $enroll_result = mysqli_query($conn, "SELECT enrolled_at FROM user_courses WHERE user_id = $user_id AND course_id = $course_id");
    $enroll = mysqli_fetch_assoc($enroll_result);
    $enrolled_date = date("F d, Y", strtotime($enroll['enrolled_at']));

    // Completion date
    $completion_date = date("F d, Y");
?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Certificate of Completion</title>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script> <!-- Include jsPDF library -->
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 20px;
                min-height: 100vh;
                display: flex;
                justify-content: center;
                align-items: center;
                background-image:
                    linear-gradient(to right, rgba(0, 180, 216, 0.8), rgba(0, 119, 182, 0.8)),
                    url('../assets/images/bg.jpg'); /* Update with actual path */
                background-size: cover;
                background-position: center;
                background-repeat: no-repeat;
            }
            .certificate {
                border: 10px solid #333;
                padding: 50px;
                max-width: 800px;
                margin: auto;
                background-color: #fff;
                text-align: center;
            }
            h1 {
                font-size: 48px;
                color: #4a4a4a;
                margin-bottom: 20px;
            }
            h2 {
                font-size: 28px;
                margin: 20px 0;
            }
            p {
                font-size: 18px;
                margin: 10px 0;
            }
            .signature {
                margin-top: 60px;
                font-style: italic;
                font-size: 16px;
            }
            .line {
                margin-top: 20px;
                width: 200px;
                border-top: 1px solid #000;
                margin-left: auto;
                margin-right: auto;
            }
            .btn {
                margin-top: 20px;
                padding: 10px 20px;
                background-color: #007bff;
                color: white;
                border: none;
                cursor: pointer;
                font-size: 16px;
                text-align: center;
                display: inline-block;
            }
            .btn:hover {
                background-color: #0056b3;
            }
            .btn-container {
                text-align: center;
                margin-top: 30px;  /* Increased margin to add more space between certificate and buttons */
            }
            @media print {
                body * {
                    visibility: hidden;
                }
                .certificate, .certificate * {
                    visibility: visible;
                }
                .certificate {
                    position: absolute;
                    left: 0;
                    top: 0;
                }
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="row">
            <div class="certificate" id="certificate">
        <h1>Certificate of Completion</h1>
        <h2>This is to certify that</h2>
        <h2><strong><?= htmlspecialchars($user['name']) ?></strong></h2>
        <p>has successfully completed the course</p>
        <h2><strong><?= htmlspecialchars($course['title']) ?></strong></h2>
        <p>under the guidance of <strong><?= htmlspecialchars($course['instructor']) ?></strong></p>
        <p>Duration: <strong><?= htmlspecialchars($course['duration']) ?> months</strong></p>
        <p>Date of Admission: <strong><?= $enrolled_date ?></strong></p>
        <p>Date of Completion: <strong><?= $completion_date ?></strong></p>

        <div class="signature">
            <div class="line"></div>
            <p>Instructor Signature</p>
        </div>

        
    </div>
    <hr>

            </div>
            <div class="row">    <div class="btn-container">
        <!-- Save PDF button -->
        <!-- <button class="btn" onclick="generatePDF()">Save as PDF</button> -->

        <!-- Print button -->
        <button class="btn" onclick="printCertificate()">Print Certificate</button>
    </div>
</div>
        </div>


    <!-- Button Container -->

    <script>
        function generatePDF() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();

            // Capture HTML content for the PDF
            const certificateElement = document.getElementById('certificate');
            doc.html(certificateElement, {
                callback: function (doc) {
                    doc.save('certificate_of_completion.pdf');  // Save the certificate as a PDF
                },
                margin: [10, 10, 10, 10]
            });
        }

        function printCertificate() {
            window.print();  // Trigger the print dialog
        }
    </script>
    </body>
    </html>

<?php
} else {
    echo "Invalid access.";
}
?>
