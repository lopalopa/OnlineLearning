<?php
// Include database connection
include('../db/db.php');

// Fetch all courses
$query = "SELECT * FROM courses ORDER BY create_at DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course List</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            min-height: 100vh;

            background-image:
                linear-gradient(to right, rgba(0, 180, 216, 0.8), rgba(0, 119, 182, 0.8)),
                url('../assets/images/bg.jpg'); /* Update with actual path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

.container {
    max-width: 1200px;
    background: #ffffff;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    margin-bottom: 30px;
    font-size: 2.5rem;
    color: #333;
}

.table th,
.table td {
    vertical-align: middle;
}

.action-btns a {
    margin: 0 10px;
    font-size: 16px;
}

.btn-custom {
    background-color: #28a745;
    color: white;
    border-radius: 50px;
    padding: 10px 20px;
    font-weight: bold;
}

.btn-custom:hover {
    background-color: #218838;
}

.btn-edit-custom {
    background-color: cyan;
    color: white;
    border-radius: 50px;
    padding: 10px 20px;
    font-weight: bold;
}
.btn-danger-custom {
    background-color: #dc3545;
    color: white;
    border-radius: 50px;
    padding: 10px 20px;
    font-weight: bold;
}

.btn-danger-custom:hover {
    background-color: #c82333;
}

.table-responsive {
    margin-top: 40px;
}

.thead-dark {
    background-color: #007bff;
    color: #fff;
}

.table-striped tbody tr:nth-child(odd) {
    background-color: #f9f9f9;
}

.table-striped tbody tr:nth-child(even) {
    background-color: #ffffff;
}

.table-bordered th,
.table-bordered td {
    border: 1px solid #dee2e6;
}

.alert-info {
    color: #0c5460;
    background-color: #d1ecf1;
    border-color: #bee5eb;
    font-size: 1.2rem;
}

.btn-success {
    background-color: #007bff;
    color: white;
    border-radius: 50px;
    padding: 12px 24px;
    font-weight: bold;
}

.btn-success:hover {
    background-color: #0056b3;
}
 </style>
</head>
<?php include '../include/header.php';?>
<body>

    <div class="container">

        <div class="row">
            <div style="text-align: right;" class="mt-5">
            <a href="add_course.php" style="text-align: right;" class="btn btn-success btn-lg">Add New Course</a>
        </div>


        <!-- Display courses in a table -->
        <?php if ($result->num_rows > 0): ?>
            <div class="table-responsive">
            <h2>Course List</h2>

                <table class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Price</th>
                            <th>Created At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($course = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $course['id']; ?></td>
                                <td><?php echo $course['title']; ?></td>
                                <td>$<?php echo number_format($course['price'], 2); ?></td>
                                <td><?php echo $course['create_at']; ?></td>
                                <td class="action-btns">
                                    <a href="course_detail_admin.php?id=<?php echo $course['id']; ?>" class="btn btn-custom">View</a>
                                    <a href="edit_course.php?id=<?php echo $course['id']; ?>" class="btn btn-edit-custom">Edit</a>
                                    <a href="delete_course.php?id=<?php echo $course['id']; ?>" class="btn btn-danger-custom" onclick="return confirm('Are you sure?');">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info" role="alert">
                No courses available.

            </div>
        <?php endif; ?>

        <!-- Add New Course Button -->
        </div>


<!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.min.js"></script>

</body>

</html>
<?php
// Close connection
$conn->close();
?>