<?php
// about.php - About Page for Online Learning Platform
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>About Us | Online Learning Platform</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;600&display=swap" rel="stylesheet" />
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Poppins', sans-serif;
      line-height: 1.6;
      background: #f9f9f9;
      color: #333;
    }

    a {
      text-decoration: none;
      color: #00b4d8;
    }

    header {
      background-color: #1a1a2e;
      color: #fff;
      padding: 20px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    header h2 {
      font-size: 24px;
    }

    nav ul {
      display: flex;
      list-style: none;
    }

    nav ul li {
      margin-left: 20px;
    }

    nav ul li a {
      color: #fff;
      font-weight: 500;
    }

    .container {
      max-width: 1100px;
      margin: auto;
      padding: 60px 20px;
    }

    .about-heading {
      text-align: center;
      margin-bottom: 40px;
    }

    .about-heading h1 {
      font-size: 2.8rem;
      color: #222;
    }

    .about-content {
      display: flex;
      flex-wrap: wrap;
      gap: 40px;
      align-items: center;
      justify-content: space-between;
    }

    .about-text {
      flex: 1;
      min-width: 300px;
    }

    .about-text h2 {
      font-size: 1.8rem;
      margin-bottom: 15px;
      color: #00b4d8;
    }

    .about-text p {
      font-size: 1rem;
      color: #444;
    }

    .about-image {
      flex: 1;
      min-width: 300px;
    }

    .about-image img {
      width: 100%;
      border-radius: 10px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    }

    .values {
      margin-top: 60px;
    }

    .values h3 {
      font-size: 1.5rem;
      margin-bottom: 20px;
    }

    .values ul {
      list-style: disc inside;
      padding-left: 10px;
    }

    footer {
      background-color: #1a1a2e;
      color: #fff;
      text-align: center;
      padding: 20px 0;
    }

    @media (max-width: 768px) {
      .about-content {
        flex-direction: column;
      }

      header {
        flex-direction: column;
        text-align: center;
      }

      nav ul {
        flex-direction: column;
        margin-top: 10px;
      }

      nav ul li {
        margin: 10px 0;
      }
    }
  </style>
</head>

<body>
  <!-- Navbar -->
  <header>
    <h2>Online Learning</h2>
    <nav>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="courses/display_list.php">Courses</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="auth/new_login.php">Login</a></li>
        <li><a href="auth/new_register.php">Sign Up</a></li>
      </ul>
    </nav>
  </header>

  <!-- Main Content -->
  <section class="container">
    <div class="about-heading">
      <h1>About Our Platform</h1>
      <p>Your trusted partner in digital education and skills development.</p>
    </div>

    <div class="about-content">
      <div class="about-text">
        <h2>Who We Are</h2>
        <p>
          Online Learning is an education-first platform built to provide accessible, flexible, and high-quality learning to students, professionals, and lifelong learners. Whether you're advancing your career, changing paths, or exploring a passion — we have something for you.
        </p>

        <h2>What We Do</h2>
        <p>
          We offer expertly crafted courses in technology, business, arts, and personal development. With our hands-on learning approach and industry-certified instructors, you're not just gaining knowledge — you're gaining career-transforming skills.
        </p>
      </div>

      <div class="about-image">
        <img src="assets/images/about.jpg" alt="About Online Learning">
      </div>
    </div>

    <div class="values">
      <h3>Our Core Values</h3>
      <ul>
        <li>💡 Accessibility for all learners</li>
        <li>🚀 Real-world, project-based learning</li>
        <li>🧠 Continuous innovation in education</li>
        <li>👨‍🏫 Community of expert instructors</li>
        <li>🏅 Career-oriented certifications</li>
      </ul>
    </div>
  </section>

  <!-- Footer -->
  <footer>
    <p>&copy; 2025 Online Learning Platform. All rights reserved.</p>
  </footer>
</body>

</html>
