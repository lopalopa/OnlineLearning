<?php
require_once '../db/db.php';
session_start();

// Ensure the current user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: new_login.php");
    exit();
}

// Delete user logic
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $current_admin_id = $_SESSION['user']['id'];

    // Prevent admin from deleting themselves
    if ($delete_id != $current_admin_id) {
        $delete_query = "DELETE FROM users WHERE id = $delete_id";
        mysqli_query($conn, $delete_query);
    }
}

// Fetch all users
$result = mysqli_query($conn, "SELECT * FROM users ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Users</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            min-height: 100vh;

            background-image:
                linear-gradient(to right, rgba(0, 180, 216, 0.8), rgba(0, 119, 182, 0.8)),
                url('../assets/images/bg.jpg'); /* Update with actual path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

        h2 {
            text-align: center;
            color: #fff;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: #ffffffcc; /* semi-transparent white background */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }

        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ccc;
        }

        th {
            background: #007bff;
            color: white;
        }

        tr:nth-child(even) {
            background: #f1f1f1;
        }

        .delete-btn, .edit-btn, .back-btn {
            padding: 5px 10px;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            color: white;
            width: 80px;
        }

        .delete-btn {
            background: red;
        }

        .delete-btn:hover {
            background: darkred;
        }

        .edit-btn {
            background: green;
        }

        .edit-btn:hover {
            background: darkgreen;
        }

        .back-btn {
            background: #00b4d8;
            text-decoration: none;
            display: inline-block;
            margin-bottom: 15px;
        }

        .back-btn:hover {
            background: #0096c7;
        }

        .back-btn a {
            color: white;
            text-decoration: none;
        }

        .logout-link {
            text-align: right;
            margin-top: 10px;
        }

        .logout-link a {
            color: #007bff;
            text-decoration: none;
        }
    </style>
</head>
<body>

    <h2>User Management</h2>

    <button class="back-btn">
        <a href="admin_dashboard.php">Back</a>
    </button>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Role</th>
                <th>Created At</th>
                <th colspan="2">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while($user = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= $user['id'] ?></td>
                    <td><?= htmlspecialchars($user['name']) ?></td>
                    <td><?= htmlspecialchars($user['email']) ?></td>
                    <td><?= htmlspecialchars($user['phone']) ?></td>
                    <td><?= htmlspecialchars($user['role']) ?></td>
                    <td><?= $user['created_at'] ?></td>
                    <td>
                        <?php if ($user['id'] != $_SESSION['user_id']): ?>
                            <a href="edit_user.php?id=<?= $user['id'] ?>">
                                <button class="edit-btn">Edit</button>
                            </a>
                        <?php else: ?>
                            (You)
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($user['id'] != $_SESSION['user_id']): ?>
                            <a href="manage_users.php?delete=<?= $user['id'] ?>" onclick="return confirm('Are you sure you want to delete this user?');">
                                <button class="delete-btn">Delete</button>
                            </a>
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

</body>
</html>
