<?php include '../include/header.php'; ?>
<?php include '../db/db.php'; ?>

<?php
$course_id = isset($_GET['course_id']) ? intval($_GET['course_id']) : 0;
$lessons = mysqli_query($conn, "SELECT * FROM lessons ");
?>

<div class="container mt-5">
    <h3>Course Lessons</h3>
    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php while ($lesson = mysqli_fetch_assoc($lessons)) {
            $lesson_id = $lesson['id'];
        ?>
        <div class="col">
            <div class="card h-100">
                <div class="card-body">
                    <h5><?= $lesson['title'] ?></h5>
                    <p><?= nl2br($lesson['content']) ?></p>

                    <!-- Action Button to check lesson status -->
                    <button class="btn btn-info" onclick="checkLessonStatus(<?= $lesson_id ?>)">Check Status</button>

                    <!-- Display status dynamically -->
                    <div id="status-<?= $lesson_id ?>" class="text-muted mt-2">Status: Not Checked</div>

                </div>
            </div>
        </div>
        <?php } ?>
    </div>
</div>

<!-- ✅ Move the JS function outside the loop -->
<script>
function checkLessonStatus(lesson_id) {
    const statusEl = document.getElementById('status-' + lesson_id);

    fetch(`lesson_status.php?lesson_id=${lesson_id}&course_id=<?= $course_id ?>`)
        .then(res => res.json())
        .then(data => {
            if (data.status) {
                statusEl.textContent = "Status: " + data.status;
                statusEl.classList.remove('text-muted', 'text-success', 'text-danger', 'text-warning');

                if (data.status === 'Completed') {
                    statusEl.classList.add('text-success');
                } else if (data.status === 'Overdue') {
                    statusEl.classList.add('text-danger');
                } else {
                    statusEl.classList.add('text-warning');
                }
            } else {
                statusEl.textContent = "Status: Unknown";
            }
        })
        .catch(err => {
            statusEl.textContent = "Error fetching status";
            console.error(err);
        });
}
</script>

<?php include '../include/footer.php'; ?>
