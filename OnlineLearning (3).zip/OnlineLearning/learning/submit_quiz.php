<?php

session_start();

$conn = new mysqli("localhost", "root", "", "learning_platform");

$student_id = $_SESSION['user_id'];

 

foreach ($_POST['quiz'] as $quiz_id => $selected_option) {

    // Fetch correct option

    $query = "SELECT correct_option FROM quizzes WHERE id = ?";

    $stmt = $conn->prepare($query);

    $stmt->bind_param("i", $quiz_id);

    $stmt->execute();

    $stmt->bind_result($correct_option);

    $stmt->fetch();

    $stmt->close();

 

    $is_correct = ($selected_option == $correct_option) ? 1 : 0;

 

    $insert = $conn->prepare("INSERT INTO quiz_attempts (student_id, quiz_id, selected_option, is_correct) VALUES (?, ?, ?, ?)");

    $insert->bind_param("iisi", $student_id, $quiz_id, $selected_option, $is_correct);

    $insert->execute();

}

 

echo "Quiz submitted!";

?>