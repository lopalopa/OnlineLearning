<?php

session_start();

$conn = new mysqli("localhost", "root", "", "learning_platform");

$student_id = $_SESSION['user_id'];

$lesson_id = $_GET['lesson_id'];

 

// Check if record exists

$query = "SELECT * FROM lesson_progress WHERE student_id = ? AND lesson_id = ?";

$stmt = $conn->prepare($query);

$stmt->bind_param("ii", $student_id, $lesson_id);

$stmt->execute();

$result = $stmt->get_result();

 

if ($result->num_rows > 0) {

    $update = $conn->prepare("UPDATE lesson_progress SET status = 'Completed', completed_at = NOW() WHERE student_id = ? AND lesson_id = ?");

    $update->bind_param("ii", $student_id, $lesson_id);

    $update->execute();

} else {

    $insert = $conn->prepare("INSERT INTO lesson_progress (student_id, lesson_id, status, completed_at) VALUES (?, ?, 'Completed', NOW())");

    $insert->bind_param("ii", $student_id, $lesson_id);

    $insert->execute();

}

 

echo "Lesson marked as completed!";

?>