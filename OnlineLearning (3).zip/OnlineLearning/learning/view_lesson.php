<?php

session_start();

$conn = new mysqli("localhost", "root", "", "learning_platform");

 

$lesson_id = $_GET['lesson_id'];

$result = $conn->query("SELECT * FROM lessons WHERE id = $lesson_id");

 

if ($row = $result->fetch_assoc()) {

    echo "<h2>{$row['title']}</h2>";

    echo "<p>{$row['content']}</p>";

    echo "<a href='mark_complete.php?lesson_id=$lesson_id'>Mark as Completed</a>";

} else {

    echo "Lesson not found!";

}

?>