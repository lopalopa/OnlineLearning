<?php

$conn = new mysqli("localhost", "root", "", "learning_platform");

$lesson_id = $_GET['lesson_id'];

 

$result = $conn->query("SELECT * FROM quizzes WHERE lesson_id = $lesson_id");

 

echo "<form action='submit_quiz.php' method='POST'>";

while ($row = $result->fetch_assoc()) {

    echo "<h4>{$row['question']}</h4>";

    echo "<input type='radio' name='quiz[{$row['id']}]' value='A'> {$row['option_a']}<br>";

    echo "<input type='radio' name='quiz[{$row['id']}]' value='B'> {$row['option_b']}<br>";

    echo "<input type='radio' name='quiz[{$row['id']}]' value='C'> {$row['option_c']}<br>";

    echo "<input type='radio' name='quiz[{$row['id']}]' value='D'> {$row['option_d']}<br>";

}

echo "<button type='submit'>Submit Quiz</button></form>";

?>