<?php

session_start();

$conn = new mysqli("localhost", "root", "", "learning_platform");

$student_id = $_SESSION['user_id'];

 

$query = "SELECT lessons.title, lesson_progress.status FROM lesson_progress

          JOIN lessons ON lessons.id = lesson_progress.lesson_id

          WHERE lesson_progress.student_id = ?";

$stmt = $conn->prepare($query);

$stmt->bind_param("i", $student_id);

$stmt->execute();

$result = $stmt->get_result();

 

echo "<h2>Your Learning Progress</h2><ul>";

while ($row = $result->fetch_assoc()) {

    echo "<li>{$row['title']} - {$row['status']}</li>";

}

echo "</ul>";

?>