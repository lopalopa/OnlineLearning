<?php
session_start();
include '../db/db.php'; // Adjust path if needed

if (!isset($_SESSION['user_id']) || !isset($_GET['lesson_id']) || !isset($_GET['course_id'])) {
    echo json_encode(['error' => 'Invalid access.']);
    exit();
}

$user_id = $_SESSION['user_id'];
$lesson_id = intval($_GET['lesson_id']);
$course_id = intval($_GET['course_id']);

// Get enrollment date
$enroll_query = $conn->prepare("SELECT enrolled_at FROM user_courses WHERE user_id = ? AND course_id = ?");
$enroll_query->bind_param("ii", $user_id, $course_id);
$enroll_query->execute();
$enroll_result = $enroll_query->get_result();

if ($enroll_result->num_rows == 0) {
    echo json_encode(['error' => 'Not enrolled in course.']);
    exit();
}

$enrolled_at = new DateTime($enroll_result->fetch_assoc()['enrolled_at']);

// Get lesson duration
$lesson_query = $conn->prepare("SELECT duration_days FROM lessons WHERE id = ?");
$lesson_query->bind_param("i", $lesson_id);
$lesson_query->execute();
$lesson_result = $lesson_query->get_result();

if ($lesson_result->num_rows == 0) {
    echo json_encode(['error' => 'Lesson not found.']);
    exit();
}

$duration_days = (int)$lesson_result->fetch_assoc()['duration_days'];
$due_date = clone $enrolled_at;
$due_date->modify("+$duration_days days");

// Check lesson progress
$progress_query = $conn->prepare("SELECT status FROM lesson_progress WHERE student_id = ? AND lesson_id = ?");
$progress_query->bind_param("ii", $user_id, $lesson_id);
$progress_query->execute();
$progress_result = $progress_query->get_result();

$status = "In Progress";
if ($progress_result->num_rows > 0) {
    $row = $progress_result->fetch_assoc();
    if ($row['status'] === 'Completed') {
        $status = "Completed";
    }
} elseif (new DateTime() > $due_date) {
    $status = "Overdue";
}

echo json_encode(['status' => $status]);
?>
