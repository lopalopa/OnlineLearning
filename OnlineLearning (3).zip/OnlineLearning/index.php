<?php
// index.php - Landing Page for Online Learning Platform
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Learning Platform</title>
    <style>
        /* General Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            color: #333;
        }

        /* Navbar */
        .navbar {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
        }

        .navbar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }

        .navbar nav ul {
            list-style: none;
            display: flex;
        }

        .navbar nav ul li {
            margin-left: 20px;
        }

        .navbar nav ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }

        .navbar .btn-primary {
            background-color: #00b4d8;
            padding: 10px 20px;
            color: #fff;
            border-radius: 5px;
            text-decoration: none;
        }

        /* Hero Section */
        .hero {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            background-size: cover;
            background-position: center;
            color: white;
        }

        .hero-content h1 {
            font-size: 3rem;
            margin-bottom: 20px;
        }

        .hero-content p {
            font-size: 1.2rem;
            margin-bottom: 20px;
        }

        .hero .btn-primary {
            background-color: #ff5722;
            padding: 15px 30px;
            font-size: 1.2rem;
            text-decoration: none;
            color: white;
        }

        /* About Section */
        .about {
            padding: 50px 20px;
            background-color: #f9f9f9;
            text-align: center;
        }

        .about h2 {
            font-size: 2.5rem;
            margin-bottom: 20px;
        }

        .features {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-top: 40px;
        }

        .feature {
            max-width: 300px;
            text-align: center;
        }

        .feature h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
        }

        /* Courses Section */
        .courses {
            padding: 50px 20px;
            text-align: center;
        }

        .courses h2 {
            font-size: 2.5rem;
            margin-bottom: 20px;
        }

        .course-list {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-top: 30px;
        }

        .course-item {
            width: 250px;
            text-align: center;
        }

        .course-item img {
            width: 100%;
            border-radius: 10px;
            margin-bottom: 15px;
        }

        .course-item h3 {
            font-size: 1.2rem;
            margin-bottom: 10px;
        }

        /* Contact Section */
        .contact {
            padding: 50px 20px;
            background-color: #333;
            color: #fff;
            text-align: center;
        }

        .contact form {
            margin-top: 20px;
        }

        .contact input,
        .contact textarea {
            width: 100%;
            padding: 15px;
            margin: 10px 0;
            border-radius: 5px;
            border: none;
        }

        .contact button {
            background-color: #ff5722;
            padding: 15px 30px;
            border: none;
            border-radius: 5px;
            color: white;
            cursor: pointer;
        }

        /* Signup Section */
        .signup {
            padding: 50px 20px;
            background-color: #f9f9f9;
            text-align: center;
        }

        .signup .btn-primary {
            background-color: #00b4d8;
            padding: 15px 30px;
            font-size: 1.2rem;

            color: white;
            border-radius: 5px;
            text-decoration: none;
        }

        /* Footer Section */
        .footer {
            padding: 20px 0;
            background-color: #333;
            color: #fff;
            text-align: center;
        }

        /* Media Queries */
        @media (max-width: 768px) {
            .features {
                flex-direction: column;
            }

            .course-list {
                flex-direction: column;
            }

            .navbar .container {
                flex-direction: column;
                text-align: center;
            }
        }
        /* Slider */
.slider {
  width: 100%;
  overflow: hidden;
  margin-top: 0;
  position: relative;
}

.slider-wrapper {
  max-width: 100%;
  position: relative;
}

.slides {
  display: flex;
  width: 300%;
  animation: slide-animation 12s infinite;
}

.slides img {
  width: 100%;
  height: 400px;
  object-fit: cover;
}

@keyframes slide-animation {
  0%   { margin-left: 0%; }
  33%  { margin-left: -100%; }
  66%  { margin-left: -200%; }
  100% { margin-left: 0%; }
}

    </style>
    <script>
        // Basic JS for interaction (Smooth Scroll or Animations)
        document.addEventListener("DOMContentLoaded", function () {
            // Add any JavaScript interactions here, like smooth scroll or animations
        });
    </script>
</head>

<body>
    <!-- Navigation Bar -->
    <!-- <header class="navbar">
        <div class="container">
           <h2>Online Learning</h2> <nav>
                <ul>
                    <li><a href="about.php">About</a></li>
                    <li><a href="#courses">Courses</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="/onlinelearning/auth/new_login.php" class="btn-primary">Login </a></li>
                    <li><a href="/onlinelearning/auth/new_register.php" class="btn-primary">Sign Up</a></li>
                    </ul>
            </nav>
        </div>
    </header> -->

    <?php include 'include/navbar.php';?>
<!-- Image Slider Section -->
<!-- <section class="slider">
  <div class="slider-wrapper">
    <div class="slides">
      <img src="assets/images/slide1.jpg" alt="Slide 1">
      <img src="assets/images/slide2.jpg" alt="Slide 2">
      <img src="assets/images/slide3.jpg" alt="Slide 3">
    </div>
  </div>
</section> -->

    <!-- Hero Section -->
    <section class="hero" style="background-image: url('assets/images/slide4.jpeg');">
        <div class="hero-content">
            <h1>Empower Your Future with Online Learning</h1>
            <p>Learn from the best instructors and start your journey to success.</p>
            <a href="auth/new_login.php" class="btn-primary">Get Started</a>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about">
        <div class="container">
            <h2>Why Choose Us?</h2>
            <p>Our platform provides high-quality courses in a variety of subjects. Learn at your own pace and gain skills that matter.</p>
            <div class="features">
            <div class="feature">
                    <h3>Expert Instructors</h3>
                    <p>Learn from professionals with years of experience.</p>
                </div>
                <div class="feature">
    <h3>Course Details</h3>
    <p>Learn from professionals in these amazing courses.</p>
    
    <!-- Link to Course List -->
    <a href="courses/display_list.php" class="btn btn-primary">View All Courses</a>
</div>

                <div class="feature">
                    <h3>Flexible Learning</h3>
                    <p>Learn anytime, anywhere with our mobile-friendly platform.</p>
                </div>
                <div class="feature">
                    <h3>Certification</h3>
                    <p>Earn certificates and boost your resume.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Courses Section -->
    <section id="courses" class="courses">
        <div class="container">
            <h2>Popular Courses</h2>
            <div class="course-list">
                <div class="course-item">
                    <img src="assets/images/course1.jpg" alt="Course 1">
                    <h3>Web Development</h3>
                    <p>Build websites from scratch with modern tools and techniques.</p>
                </div>
                <div class="course-item">
                    <img src="assets/images/course2.png" alt="Course 2">
                    <h3>Data Science</h3>
                    <p>Learn data analysis, machine learning, and more.</p>
                </div>
                <div class="course-item">
                    <img src="assets/images/course3.jpg" alt="Course 3">
                    <h3>Digital Marketing</h3>
                    <p>Master SEO, social media, and paid advertising strategies.</p>
                </footer>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact">
        <div class="container">
            <h2>Get In Touch</h2>
            <p>If you have any questions, feel free to contact us!</p>
            <form action="submit_contact.php" method="POST">
                <input type="text" name="name" placeholder="Your Name" required>
                <input type="email" name="email" placeholder="Your Email" required>
                <textarea name="message" placeholder="Your Message" required></textarea>
                <button type="submit" class="btn-primary">Send Message</button>
            </form>
        </div>
    </section>

    <!-- Signup Section -->
    <section id="signup" class="signup">
        <div class="container">
            <h2>Join Our Platform Today!</h2>
            <p>Start learning and unlock your potential.</p>
            <a href="auth/new_register.php" class="btn-primary">Sign Up Now</a>
        </div>
    </section>

    <!-- Footer Section -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 Online Learning Platform. All rights reserved.</p>
        </div>
</body>

</html>
