<?php

require_once '../db/db.php';

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    $phone = trim($_POST['phone']);
    $role = trim($_POST['role']);

    $errors = [];

    // Validate required fields
    if (empty($name) || empty($email) || empty($password) || empty($confirm_password) || empty($role)) {
        $errors[] = "All fields except phone are required!";
    }

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format!";
    }

    // Validate phone number (optional, must be numeric if provided)
    if (!empty($phone) && !preg_match("/^[0-9]{10,15}$/", $phone)) {
        $errors[] = "Invalid phone number!";
    }

    // Check password length
    if (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters!";
    }

    // Check if passwords match
    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match!";
    }

    // Restrict multiple Admins
    if ($role === "admin") {
        $admin_check_query = "SELECT id FROM users WHERE role = 'admin'";
        $admin_result = mysqli_query($conn, $admin_check_query);

        if (mysqli_num_rows($admin_result) > 0) {
            $errors[] = "An Admin already exists! Only one Admin is allowed.";
        }
    }

    // Check if email already exists
    $email_check_query = "SELECT id FROM users WHERE email = '$email'";
    $email_result = mysqli_query($conn, $email_check_query);

    if (mysqli_num_rows($email_result) > 0) {
        $errors[] = "Email already registered!";
    }

    // If no errors, insert user
    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);

        $insert_query = "INSERT INTO users (name, email, password, phone, role)
                         VALUES ('$name', '$email', '$hashed_password', '$phone', '$role')";

        if (mysqli_query($conn, $insert_query)) {
            $_SESSION['success'] = "Registration successful! You can now log in.";
            header("Location: login.php");
            exit();
        } else {
            $errors[] = "Registration failed! Please try again.";
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
            padding: 30px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
            font-family: 'Arial', sans-serif;
            color: #333;
        }
        .form-group label {
            font-weight: bold;
        }
        .form-control {
            border-radius: 4px;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        .btn-primary {
            width: 100%;
            padding: 12px;
            border-radius: 4px;
            font-size: 16px;
        }
        .error {
            color: #ff6b6b;
            font-weight: bold;
        }
        .success {
            color: #28a745;
            font-weight: bold;
        }
        .already-registered {
            text-align: center;
            margin-top: 20px;
        }
        .form-select {
            border-radius: 4px;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Register</h2>

    <?php
    if (!empty($errors)) {
        echo '<div class="error">';
        foreach ($errors as $error) {
            echo "<p>$error</p>";
        }
        echo '</div>';
    }

    if (isset($_SESSION['success'])) {
        echo '<div class="success"><p>' . $_SESSION['success'] . '</p></div>';
        unset($_SESSION['success']);
    }
    ?>

    <form action="register.php" method="POST">
        <div class="form-group mb-3">
            <label for="name">Full Name:</label>
            <input type="text" name="name" class="form-control" required>
        </div>

        <div class="form-group mb-3">
            <label for="email">Email:</label>
            <input type="email" name="email" class="form-control" required>
        </div>

        <div class="form-group mb-3">
            <label for="password">Password:</label>
            <input type="password" name="password" class="form-control" required>
        </div>

        <div class="form-group mb-3">
            <label for="confirm_password">Confirm Password:</label>
            <input type="password" name="confirm_password" class="form-control" required>
        </div>

        <div class="form-group mb-3">
            <label for="phone">Phone (Optional):</label>
            <input type="text" name="phone" class="form-control">
        </div>

        <div class="form-group mb-3">
            <label for="role">Select Role:</label>
            <select name="role" class="form-select" required>
                <option value="user">User</option>
                <option value="admin">Admin</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Register</button>
    </form>

    <div class="already-registered">
        <p>Already have an account? <a href="login.php">Login here</a>.</p>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
