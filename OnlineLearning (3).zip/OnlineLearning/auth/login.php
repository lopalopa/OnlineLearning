$email = trim($_POST['email']);
<?php

require_once '../db/db.php';

session_start();

 

if ($_SERVER["REQUEST_METHOD"] == "POST") {


    $password = trim($_POST['password']);

    $errors = [];

 

    // Validate input fields

    if (empty($email) || empty($password)) {

        $errors[] = "Email and Password are required!";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $errors[] = "Invalid email format!";

    }

 

    if (empty($errors)) {

        // Fetch user details from the database

        $query = "SELECT * FROM users WHERE email = '$email'";

        $result = mysqli_query($conn, $query);

 

        if ($row = mysqli_fetch_assoc($result)) {

            // Verify the hashed password

            if (password_verify($password, $row['password'])) {

                $_SESSION['user_id'] = $row['id'];

                $_SESSION['user_name'] = $row['name'];

                $_SESSION['user_email'] = $row['email'];

                $_SESSION['user_role'] = $row['role'];

 

                // Redirect user based on role

                if ($row['role'] === 'admin') {

                    header("Location: ../admin/admin_dashboard.php");

                } else {

                    header("Location: ../user/user_dashboard.php");

                }

                exit();

            } else {

                $errors[] = "Incorrect password!";

            }

        } else {

            $errors[] = "No account found with this email!";

        }

    }

}

?>

 

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login</title>

    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body>

 

<?php include '../include/navbar.php'; ?>

 

<div class="container">

    <h2>Login</h2>

 

    <?php

    if (!empty($errors)) {

        echo '<div class="error">';

        foreach ($errors as $error) {

            echo "<p>$error</p>";

        }

        echo '</div>';

    }

    ?>

 

    <form action="login.php" method="POST">

        <label for="email">Email:</label>

        <input type="email" name="email" required>

 

        <label for="password">Password:</label>

        <input type="password" name="password" required>

 

        <button type="submit">Login</button>

    </form>

 

    <p>Don't have an account? <a href="register.php">Register here</a>.</p>

</div>

 

<?php include '../includes/footer.php'; ?>

 

</body>

</html>